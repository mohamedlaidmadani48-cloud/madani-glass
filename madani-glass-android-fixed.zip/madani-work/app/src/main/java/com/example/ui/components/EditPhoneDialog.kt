package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.db.PhoneEntity
import com.example.ui.language.Strings

@Composable
fun EditPhoneDialog(
    phone: PhoneEntity,
    onDismiss: () -> Unit,
    onSavePhone: (PhoneEntity) -> Unit,
    onDeletePhone: (PhoneEntity) -> Unit
) {
    var brand by remember { mutableStateOf(phone.brand) }
    var modelName by remember { mutableStateOf(phone.modelName) }
    var modelCode by remember { mutableStateOf(phone.modelCode) }
    var screenSizeText by remember { mutableStateOf(phone.screenSizeInch.toString()) }
    var screenType by remember { mutableStateOf(phone.screenType) }
    var compatibleModels by remember { mutableStateOf(phone.compatibleModels) }
    var glassType by remember { mutableStateOf(phone.glassType) }
    var cameraCutout by remember { mutableStateOf(phone.cameraCutout) }
    var tempText by remember { mutableStateOf(phone.separationTempCelsius.toString()) }
    var wireSize by remember { mutableStateOf(phone.wireSizeMm) }
    var ocaType by remember { mutableStateOf(phone.ocaType) }
    var technicianNotes by remember { mutableStateOf(phone.technicianNotes) }
    var userNotes by remember { mutableStateOf(phone.userNotes) }

    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp))
                .testTag("edit_phone_dialog"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with Title and Delete Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✏️ " + Strings.get("edit_compatibility"),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    IconButton(
                        onClick = { showDeleteConfirmDialog = true },
                        modifier = Modifier.testTag("delete_phone_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = Color(0xFFFF5252)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                CustomTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = Strings.get("brand"),
                    testTag = "edit_brand"
                )

                CustomTextField(
                    value = modelName,
                    onValueChange = { modelName = it },
                    label = Strings.get("model_name") + " *",
                    testTag = "edit_model_name"
                )

                CustomTextField(
                    value = modelCode,
                    onValueChange = { modelCode = it },
                    label = Strings.get("model_code"),
                    testTag = "edit_model_code"
                )

                CustomTextField(
                    value = screenSizeText,
                    onValueChange = { screenSizeText = it },
                    label = Strings.get("screen_size") + " (e.g. 6.5)",
                    testTag = "edit_screen_size"
                )

                CustomTextField(
                    value = screenType,
                    onValueChange = { screenType = it },
                    label = Strings.get("screen_type") + " (e.g. Super AMOLED 120Hz)",
                    testTag = "edit_screen_type"
                )

                CustomTextField(
                    value = compatibleModels,
                    onValueChange = { compatibleModels = it },
                    label = Strings.get("compatible_models"),
                    testTag = "edit_compatible_models"
                )

                CustomTextField(
                    value = glassType,
                    onValueChange = { glassType = it },
                    label = Strings.get("glass_details"),
                    testTag = "edit_glass_type"
                )

                CustomTextField(
                    value = cameraCutout,
                    onValueChange = { cameraCutout = it },
                    label = Strings.get("camera_notch"),
                    testTag = "edit_camera_cutout"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = tempText,
                        onValueChange = { tempText = it },
                        label = { Text(Strings.get("separation_temp") + " (°C)", style = MaterialTheme.typography.bodySmall) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("edit_temp")
                    )

                    OutlinedTextField(
                        value = wireSize,
                        onValueChange = { wireSize = it },
                        label = { Text(Strings.get("wire_gauge"), style = MaterialTheme.typography.bodySmall) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("edit_wire")
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                CustomTextField(
                    value = ocaType,
                    onValueChange = { ocaType = it },
                    label = Strings.get("oca_type"),
                    testTag = "edit_oca"
                )

                CustomTextField(
                    value = technicianNotes,
                    onValueChange = { technicianNotes = it },
                    label = Strings.get("technician_notes"),
                    testTag = "edit_technician_notes"
                )

                CustomTextField(
                    value = userNotes,
                    onValueChange = { userNotes = it },
                    label = Strings.get("user_notes"),
                    testTag = "edit_user_notes"
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("cancel_edit_phone")
                    ) {
                        Text(Strings.get("cancel"))
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (modelName.isNotBlank()) {
                                val updatedPhone = phone.copy(
                                    brand = brand.trim().ifEmpty { "Generic" },
                                    modelName = modelName.trim(),
                                    modelCode = modelCode.trim(),
                                    screenSizeInch = screenSizeText.toDoubleOrNull() ?: phone.screenSizeInch,
                                    screenType = screenType.trim(),
                                    compatibleModels = compatibleModels.trim().ifEmpty { modelName },
                                    glassType = glassType.trim(),
                                    cameraCutout = cameraCutout.trim(),
                                    separationTempCelsius = tempText.toIntOrNull() ?: phone.separationTempCelsius,
                                    wireSizeMm = wireSize.trim(),
                                    ocaType = ocaType.trim(),
                                    technicianNotes = technicianNotes.trim(),
                                    userNotes = userNotes.trim()
                                )
                                onSavePhone(updatedPhone)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("save_edit_phone")
                    ) {
                        Text(Strings.get("save"), color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(
                    text = Strings.get("delete_confirm_title"),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = Strings.get("delete_confirm_msg"),
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeletePhone(phone)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text(Strings.get("delete_device"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text(Strings.get("cancel"))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
private fun CustomTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    testTag: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, style = MaterialTheme.typography.bodySmall) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
            focusedLabelColor = MaterialTheme.colorScheme.primary
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag(testTag)
    )
}
