package com.example.data.model

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class RefurbishStageVideo(
    val id: String,
    val stageNumber: Int,
    val titleAr: String,
    val titleEn: String,
    val titleFr: String,
    val duration: String,
    val youtubeVideoId: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val descriptionFr: String,
    val tipsAr: List<String>,
    val tipsEn: List<String>,
    val tipsFr: List<String>,
    val toolsNeededAr: String,
    val toolsNeededEn: String,
    val toolsNeededFr: String,
    val recommendedTemp: String,
    val wireThickness: String,
    val targetScreenType: String
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("stageNumber", stageNumber)
        obj.put("titleAr", titleAr)
        obj.put("titleEn", titleEn)
        obj.put("titleFr", titleFr)
        obj.put("duration", duration)
        obj.put("youtubeVideoId", youtubeVideoId)
        obj.put("descriptionAr", descriptionAr)
        obj.put("descriptionEn", descriptionEn)
        obj.put("descriptionFr", descriptionFr)
        
        val tipsArray = JSONArray()
        tipsAr.forEach { tipsArray.put(it) }
        obj.put("tipsAr", tipsArray)

        obj.put("toolsNeededAr", toolsNeededAr)
        obj.put("toolsNeededEn", toolsNeededEn)
        obj.put("toolsNeededFr", toolsNeededFr)
        obj.put("recommendedTemp", recommendedTemp)
        obj.put("wireThickness", wireThickness)
        obj.put("targetScreenType", targetScreenType)
        return obj
    }

    companion object {
        fun fromJson(obj: JSONObject): RefurbishStageVideo {
            val tipsList = mutableListOf<String>()
            val arr = obj.optJSONArray("tipsAr")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    tipsList.add(arr.getString(i))
                }
            }
            return RefurbishStageVideo(
                id = obj.optString("id", UUID.randomUUID().toString()),
                stageNumber = obj.optInt("stageNumber", 1),
                titleAr = obj.optString("titleAr", "فيديو تعليمي"),
                titleEn = obj.optString("titleEn", "Tutorial Video"),
                titleFr = obj.optString("titleFr", "Vidéo Tutoriel"),
                duration = obj.optString("duration", "05:00"),
                youtubeVideoId = obj.optString("youtubeVideoId", "dQw4w9WgXcQ"),
                descriptionAr = obj.optString("descriptionAr", "وصف الشرح والتطبيق العملي"),
                descriptionEn = obj.optString("descriptionEn", "Video description"),
                descriptionFr = obj.optString("descriptionFr", "Description de la vidéo"),
                tipsAr = tipsList.ifEmpty { listOf("اتبّع التعليمات بدقة") },
                tipsEn = listOf("Follow instructions carefully"),
                tipsFr = listOf("Suivez attentivement les instructions"),
                toolsNeededAr = obj.optString("toolsNeededAr", "سخان شاشات، سلك قطع"),
                toolsNeededEn = obj.optString("toolsNeededEn", "Separator, wire"),
                toolsNeededFr = obj.optString("toolsNeededFr", "Séparateur, fil"),
                recommendedTemp = obj.optString("recommendedTemp", "85°C"),
                wireThickness = obj.optString("wireThickness", "0.028 mm"),
                targetScreenType = obj.optString("targetScreenType", "All")
            )
        }
    }
}

object RefurbishTutorialsData {
    private const val PREFS_NAME = "refurbish_tutorials_prefs"
    private const val KEY_VIDEOS_JSON = "custom_videos_json"

    val videosState = mutableStateOf<List<RefurbishStageVideo>>(emptyList())

    val stagesList: List<RefurbishStageVideo>
        get() = if (videosState.value.isNotEmpty()) videosState.value else defaultStagesList

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_VIDEOS_JSON, null)
        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                val loadedList = mutableListOf<RefurbishStageVideo>()
                for (i in 0 until array.length()) {
                    loadedList.add(RefurbishStageVideo.fromJson(array.getJSONObject(i)))
                }
                if (loadedList.isNotEmpty()) {
                    videosState.value = loadedList
                    return
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        videosState.value = defaultStagesList
    }

    private fun saveList(context: Context, list: List<RefurbishStageVideo>) {
        val array = JSONArray()
        list.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_VIDEOS_JSON, array.toString())
            .apply()
        videosState.value = list
    }

    fun addVideo(context: Context, video: RefurbishStageVideo) {
        val current = stagesList.toMutableList()
        current.add(video)
        saveList(context, current)
    }

    fun updateVideo(context: Context, updated: RefurbishStageVideo) {
        val current = stagesList.toMutableList()
        val index = current.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            current[index] = updated
            saveList(context, current)
        }
    }

    fun deleteVideo(context: Context, videoId: String) {
        val current = stagesList.filter { it.id != videoId }
        saveList(context, current)
    }

    fun resetToDefaults(context: Context) {
        saveList(context, defaultStagesList)
    }

    val defaultStagesList = listOf(
        RefurbishStageVideo(
            id = "stage_1",
            stageNumber = 1,
            titleAr = "المرحلة 1: الفحص والأختبار الأول لللمس والإضاءة",
            titleEn = "Stage 1: Pre-Disassembly Touch & Display Test",
            titleFr = "Étape 1 : Test pré-démontage du tactile et affichage",
            duration = "03:20",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "اختبار جميع أجزاء اللمس (Touch Digitizer) والتأكد من عدم وجود بقع سوداء أو خطوط عمودية قبل البدء في فك الزجاج حتى لا تُحمل العطل للشاشة.",
            descriptionEn = "Test all touch areas and inspect for black spots or vertical lines prior to glass removal.",
            descriptionFr = "Testez toutes les zones tactiles et vérifiez l'absence de taches noires avant le démontage.",
            tipsAr = listOf(
                "ادخل كود الاختيار *#0*# في هواتف سامسونج لفحص الألوان واللمس.",
                "تأكد من عدم وجود كسر في طبقة العرض الداخلية (Display Panel).",
                "صوّر الشاشة قبل الفك لتوثيق حالتها للزبون."
            ),
            tipsEn = listOf(
                "Use *#0*# test mode on Samsung devices.",
                "Ensure inner OLED/LCD panel has no micro cracks.",
                "Take a photo of the display state before disassembly."
            ),
            tipsFr = listOf(
                "Utilisez le code *#0*# sur Samsung.",
                "Vérifiez que la dalle OLED/LCD n'a pas de micro-fissures.",
                "Prenez une photo de l'écran avant démontage."
            ),
            toolsNeededAr = "جهاز فحص اللمس، كحول تنظيف بسيط، شاحن اختبار",
            toolsNeededEn = "Touch test equipment, IPA, charger",
            toolsNeededFr = "Équipement de test, IPA, chargeur",
            recommendedTemp = "بدون حرارة",
            wireThickness = "غير مطلوب",
            targetScreenType = "All"
        ),

        RefurbishStageVideo(
            id = "stage_2",
            stageNumber = 2,
            titleAr = "المرحلة 2: التسخين وفك الشاشة عن فريم الهاتف",
            titleEn = "Stage 2: Heating & Frame Separation",
            titleFr = "Étape 2 : Chauffage et séparation du châssis",
            duration = "05:45",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "تسخين الهاتف على مسخن الشاشات (Separator Bed) عند حرارة 80°C - 85°C لإذابة غراء الفريم بدون إتلاف البطارية أو الإضاءة الخلفية.",
            descriptionEn = "Heat the device on heating separator at 80°C-85°C to soften frame adhesive without damaging battery or backlight.",
            descriptionFr = "Chauffez l'appareil à 80°C-85°C pour ramollir la colle du châssis.",
            tipsAr = listOf(
                "استخدم شريحة بلاستيكية مرنة (مثل بطاقة OCA) مع قطرات قليل من كحول 99%.",
                "تجنب تعميق الشريحة في أسفل الشاشة لحماية فلاتة العرض (Flex Cable).",
                "في شاشات LCD تجنب وصول الكحول لطبقة الإضاءة (Backlight)."
            ),
            tipsEn = listOf(
                "Use thin plastic card with minor 99% IPA drops.",
                "Do not insert card deeply at the bottom flex area.",
                "Avoid alcohol ingress in LCD backlight layers."
            ),
            tipsFr = listOf(
                "Utilisez une carte plastique fine avec un peu d'IPA 99%.",
                "Ne pas enfoncer la carte en bas près de la nappe flex.",
                "Évitez l'alcool dans le rétroéclairage LCD."
            ),
            toolsNeededAr = "مسخن سخان 85°C، شفرة بلاستيك مرنة، قطارة كحول IPA 99%",
            toolsNeededEn = "Heating pad (85°C), plastic cards, IPA 99%",
            toolsNeededFr = "Plaque chauffante (85°C), cartes plastique, IPA 99%",
            recommendedTemp = "80°C - 85°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "All"
        ),

        RefurbishStageVideo(
            id = "stage_3",
            stageNumber = 3,
            titleAr = "المرحلة 3: قص وفصل الزجاج المكسور بالسلك (Cutting Wire)",
            titleEn = "Stage 3: Cutting Broken Glass with Separation Wire",
            titleFr = "Étape 3 : Séparation de la vitre cassée avec fil",
            duration = "07:10",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "عزل الزجاج التالف باستخدام سلك صلب ناعم 0.03mm أو 0.028mm بزاوية حادة مائلة للأسفل لتفادي خدش طبقة البولاريزر (Polarizer).",
            descriptionEn = "Separate damaged glass using 0.03mm / 0.028mm molybdenum wire angled low to prevent Polarizer cuts.",
            descriptionFr = "Séparez la vitre endommagée avec un fil de 0.03mm ou 0.028mm.",
            tipsAr = listOf(
                "احرص على إبقاء السلك ملاصقاً للزجاج العلوي بدلاً من الشاشة الداخلية.",
                "اسحب السلك بحركة منشارية سلسة يميناً ويساراً.",
                "إذا كان الزجاج شديد التفتت ضع شريط لاصق شفاف (Tape) لثبات المشفوط."
            ),
            tipsEn = listOf(
                "Keep wire pressed upward against broken glass.",
                "Use gentle left-right sawing motion.",
                "Apply clear tape over shattered glass to improve vacuum grip."
            ),
            tipsFr = listOf(
                "Gardez le fil plaqué vers la vitre du haut.",
                "Mouvement de scie fluide de gauche à droite.",
                "Appliquez du ruban adhésif sur la vitre très cassée."
            ),
            toolsNeededAr = "سخان شفطVacuum، سلك قطع 0.03mm، شريط لاصق شفاف",
            toolsNeededEn = "Vacuum separator, 0.03mm wire, clear packing tape",
            toolsNeededFr = "Séparateur sous vide, fil 0.03mm, ruban adhésif",
            recommendedTemp = "85°C - 90°C",
            wireThickness = "0.028 - 0.03 mm",
            targetScreenType = "All"
        ),

        RefurbishStageVideo(
            id = "stage_4",
            stageNumber = 4,
            titleAr = "المرحلة 4: إزالة غراء الـ OCA القديم وتنظيف الشاشة",
            titleEn = "Stage 4: Glue Removal & Screen Cleaning",
            titleFr = "Étape 4 : Enlèvement de la colle OCA et nettoyage",
            duration = "04:50",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "استخدام دريل إزالة الغراء (OCA Glue Remover Tool) ومذيب الغراء الخاص لإزالة الطبقة القديمة تماماً وجعل الشاشة ناصعة كالمصنع.",
            descriptionEn = "Remove old OCA glue using motor remover tool and 8333 glue liquid cleaner.",
            descriptionFr = "Enlevez l'ancienne colle OCA avec un outil rotatif et solvant.",
            tipsAr = listOf(
                "لا تضغط بشدة بالدريل على منتصف الشاشة لمنع تشكل البقع.",
                "امسح بقطعة قماش ناعمة (Microfiber) غير مزغبة.",
                "افحص الشاشة تحت ضوء كاشف الغبار (Dust Detection Lamp)."
            ),
            tipsEn = listOf(
                "Do not apply heavy downward motor pressure.",
                "Use lint-free microfiber cloth.",
                "Inspect under UV dust detection lamp."
            ),
            tipsFr = listOf(
                "Ne pas appuyer fort avec l'outil rotatif.",
                "Utilisez un chiffon microfibre non pelucheux.",
                "Inspectez sous lampe anti-poussière."
            ),
            toolsNeededAr = "دريل OCA، سائل 8333 أو 530، قماش Microfiber، لمبة كشف الغبار",
            toolsNeededEn = "OCA motor drill, 8333 liquid, Microfiber cloth, Dust light",
            toolsNeededFr = "Moteur OCA, solvant 8333, chiffon microfibre, lampe UV",
            recommendedTemp = "40°C - 50°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "All"
        ),

        RefurbishStageVideo(
            id = "stage_5",
            stageNumber = 5,
            titleAr = "المرحلة 5: تركيب فيلم الـ OCA والزجاج الجديد بالمحاذاة",
            titleEn = "Stage 5: OCA Sheet Application & Glass Mold Alignment",
            titleFr = "Étape 5 : Application du film OCA et alignement de la vitre",
            duration = "06:15",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "تثبيت لاصق الـ OCA السليم باستخدام الرولر (OCA Roller) ثم وضع الشاشة داخل قالب المحاذاة (Alignment Mold) لتركيب الزجاج في المركز بدقة.",
            descriptionEn = "Apply fresh OCA film using silicone roller, then place display in precise mold for perfect glass positioning.",
            descriptionFr = "Appliquez le film OCA avec rouleau en silicone, puis placez dans le moule d'alignement.",
            tipsAr = listOf(
                "تأكد من البيئة الخالية من الغبار (Dust-Free Clean Room/Box).",
                "انزع غلاف الـ OCA بسرعة ورفق لتفادي التقاط الغبار.",
                "ثبت نقطة سنتر بالمنتصف بأصبعك قبل وضعها في المكبس."
            ),
            tipsEn = listOf(
                "Operate inside a dust-free workstation/box.",
                "Peel protective OCA liner smoothly in one motion.",
                "Lightly tack center point before entering laminator."
            ),
            tipsFr = listOf(
                "Travaillez dans un environnement sans poussière.",
                "Retirez le film protecteur d'un geste fluide.",
                "Pressez légèrement le centre avant la presse."
            ),
            toolsNeededAr = "رولر سيليكون، قالب محاذاة الموديل (Mold)، باغة زجاجية جديدة بـ OCA",
            toolsNeededEn = "Silicone roller, alignment mold, replacement glass with OCA",
            toolsNeededFr = "Rouleau silicone, moule d'alignement, nouvelle vitre avec OCA",
            recommendedTemp = "حرارة الغرفة 25°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "All"
        ),

        RefurbishStageVideo(
            id = "stage_6",
            stageNumber = 6,
            titleAr = "المرحلة 6: الكبس الحراري وتفريغ الفقاعات (Lamination & Autoclave)",
            titleEn = "Stage 6: Vacuum Lamination & Autoclave Bubble Removal",
            titleFr = "Étape 6 : Stratification sous vide et élimination des bulles",
            duration = "05:10",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "وضع الشاشة داخل آلة الكبس (Laminating Machine) تحت ضغط مفرغ من الهواء، ثم نفلها للغرفة الحرارية (Autoclave Bubble Remover) لضمان اختفاء كل الفقاعات 100%.",
            descriptionEn = "Place glass in vacuum laminator, then move to Autoclave de-bubbler at 0.5 MPa / 45°C for 5-8 minutes.",
            descriptionFr = "Placez dans la plastifieuse sous vide puis dans l'autoclave de-bubbler à 0.5 MPa.",
            tipsAr = listOf(
                "ضبط ضغط الكبس عند 0.35 - 0.45 MPa.",
                "حرارة الـ Autoclave المثالية: 45°C - 50°C لمدة 5 إلى 8 دقائق.",
                "اختبر الشاشة بعد التبريد للتأكد من المظهر النهائي والمطابقة."
            ),
            tipsEn = listOf(
                "Set lamination pressure to 0.35 - 0.45 MPa.",
                "Autoclave de-bubbler setting: 45°C - 50°C for 5-8 minutes.",
                "Test touch and display after panel cools."
            ),
            tipsFr = listOf(
                "Réglez la pression de stratification entre 0.35 et 0.45 MPa.",
                "Réglage autoclave : 45°C - 50°C pendant 5 à 8 minutes.",
                "Testez l'écran après refroidissement."
            ),
            toolsNeededAr = "مكبس OCA Laminator، آلة تفريغ الفقاعات Autoclave، ضاغط هواء Compressor",
            toolsNeededEn = "Vacuum laminator, Autoclave de-bubbler, Air compressor",
            toolsNeededFr = "Plastifieuse sous vide, Autoclave anti-bulles, Compresseur",
            recommendedTemp = "45°C - 50°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "General"
        ),

        RefurbishStageVideo(
            id = "stage_7_iphone",
            stageNumber = 7,
            titleAr = "تجديد زجاج الآيفون: نزع الفريم وحماية فلاتة اللمس (iPhone Glass & Frame)",
            titleEn = "iPhone Glass Refurbishing: Frame Removal & Flex Protection",
            titleFr = "Remplacement vitre iPhone : Démontage châssis et protection nappe",
            duration = "08:35",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "دليل احترافي لتجديد زجاج أجهزة الآيفون (iPhone 11 إلى iPhone 15 Pro Max). يغطي كيفية تسخين فريم الآيفون ونزعه بسلامة دون تمزيق فلاتات العرض السفيلية، مع التغذية بالسلك الناعم 0.028mm.",
            descriptionEn = "Professional guide for iPhone glass replacement (iPhone 11 to 15 Pro Max). Cover frame heating, flex protection, and 0.028mm wire cutting.",
            descriptionFr = "Guide professionnel pour remplacer la vitre iPhone (11 à 15 Pro Max). Protection de la nappe et fil 0.028mm.",
            tipsAr = listOf(
                "استخدم حرارة 80°C - 85°C لنزع بلاستيك الفريم دون إتلاف المكونات.",
                "ضع براغي التثبيت أو عازل الحرارة على فلاتة الـ IC السفلي قبل القطع.",
                "استخدم سلك مرن 0.028mm لتفادي خدش طبقة البولاريزر الأصلي لآيفون."
            ),
            tipsEn = listOf(
                "Heat frame at 80°C - 85°C to soften original border frame glue.",
                "Apply thermal tape or protective shield over bottom flex IC area.",
                "Use fine 0.028mm molybdenum wire to protect Apple original polarizer."
            ),
            tipsFr = listOf(
                "Chauffez le châssis à 80°C - 85°C pour ramollir la colle d'origine.",
                "Appliquez du ruban thermique sur la nappe IC en bas.",
                "Utilisez un fil fin de 0.028mm pour protéger le polariseur d'origine."
            ),
            toolsNeededAr = "مسخن شاشات 85°C، سلك قطع 0.028mm، شريط عازل حراري Kapton Tape، قالب آيفون",
            toolsNeededEn = "Heating separator 85°C, 0.028mm wire, Kapton heat tape, iPhone mold",
            toolsNeededFr = "Séparateur 85°C, fil 0.028mm, ruban Kapton, moule iPhone",
            recommendedTemp = "80°C - 85°C",
            wireThickness = "0.028 mm",
            targetScreenType = "iPhone"
        ),

        RefurbishStageVideo(
            id = "stage_8_iphone_notch",
            stageNumber = 8,
            titleAr = "آيفون: تنظيف منطقة النوتش Notch / Dynamic Island وتركيب باغة OCA",
            titleEn = "iPhone: Notch / Dynamic Island Area Cleaning & OCA Alignment",
            titleFr = "iPhone : Nettoyage encoche / Dynamic Island et pose OCA",
            duration = "06:40",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "حماية مستشعرات التقارب و FaceID والكاميرا الأمامية أثناء إزالة الغراء، وتركيب باغة زجاجية تحتوي على فتحة Notch دقيقة لمنع حدوث بقع دبابيس أو ضبابية الكاميرا.",
            descriptionEn = "Protect proximity sensors, FaceID & front camera during glue cleanup, applying precise notch OCA glass.",
            descriptionFr = "Protégez le FaceID et la caméra avant pendant le nettoyage et posez la vitre OCA.",
            tipsAr = listOf(
                "ضع ملصق عازل على عدسة الكاميرا والسنسور قبل مسح الغراء بالكحول.",
                "استخدم قوالب كبس مخصصة لفتحة النوتش (iPhone Notch Rubber Pad).",
                "افحص نقاء منطقة الكاميرا بقلم الضوء قبل وضع الزجاج الجديد."
            ),
            tipsEn = listOf(
                "Cover camera lens and proximity sensors with protective sticker before cleaning.",
                "Use dedicated iPhone Notch Rubber Pad inside laminator.",
                "Inspect camera window area under bright dust light before final lamination."
            ),
            tipsFr = listOf(
                "Couvrez l'objectif de la caméra et les capteurs avec un autocollant protecteur.",
                "Utilisez un tapis en caoutchouc spécial encoche iPhone.",
                "Inspectez la zone caméra sous lampe anti-poussière avant plastification."
            ),
            toolsNeededAr = "شريط عزل الكاميرا، وسادة كبس Notch Rubber، باغة آيفون بـ OCA أصيلة",
            toolsNeededEn = "Camera protection tape, Notch rubber pad, iPhone OCA glass",
            toolsNeededFr = "Ruban de protection caméra, tapis caoutchouc Notch, vitre OCA iPhone",
            recommendedTemp = "45°C - 50°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "iPhone"
        ),

        RefurbishStageVideo(
            id = "stage_9_edge_cut",
            stageNumber = 9,
            titleAr = "شاشات Edge المنحنية: تقنية قص وفصل الزجاج المنحني بالسلك (Curved Screen Cut)",
            titleEn = "Curved Edge Display: Precision Wire Separation Technique",
            titleFr = "Écran Incurvé Edge : Technique de découpe et séparation au fil",
            duration = "10:15",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "احتراف قص وفصل زجاج شاشات سامسونج المنحنية (Samsung S21 / S22 / S23 Ultra / Edge). شرح دخول السلك الذهبي 0.025mm بزاوية 45° من الانحناء الجانبي لمنع كسر أو ثقب طبقة الـ OLED.",
            descriptionEn = "Mastering Samsung Curved OLED separation (S21/S22/S23 Ultra). Entering 0.025mm gold wire at a 45° angled curve to avoid OLED puncture.",
            descriptionFr = "Maîtrise de la séparation des écrans incurvés Samsung OLED (S21/S22/S23 Ultra). Fil de 0.025mm à angle de 45°.",
            tipsAr = listOf(
                "ثبت الشاشة بمسخن 360 درجة المائل ذو الشفط القوي.",
                "ادخل بالسلك دائماً من الزاوية العلوية المائلة بزاوية 45 درجة بحذر شديد.",
                "استخدم سلك ذهبي رفيع جداً 0.025mm أو 0.020mm واجعله ملامساً للزجاج العلوي."
            ),
            tipsEn = listOf(
                "Fix display on 360° rotating vacuum separator with strong suction.",
                "Enter wire at a strict 45° downward angle from top curved corner.",
                "Use ultra-fine 0.025mm or 0.020mm gold wire kept flat against top glass."
            ),
            tipsFr = listOf(
                "Fixez l'écran sur le séparateur rotatif à 360° avec aspiration puissante.",
                "Insérez le fil à un angle de 45° depuis le coin supérieur incurvé.",
                "Utilisez un fil d'or très fin de 0.025mm ou 0.020mm bien plaqué."
            ),
            toolsNeededAr = "سخان 360° خاص بالايدج Edge، سلك ذهبي 0.025mm، وسادة حماية سيليكون",
            toolsNeededEn = "360° Edge vacuum separator, 0.025mm gold wire, silicone protection pad",
            toolsNeededFr = "Séparateur 360° spécial Edge, fil d'or 0.025mm, tapis silicone",
            recommendedTemp = "85°C - 90°C",
            wireThickness = "0.020 - 0.025 mm",
            targetScreenType = "Edge"
        ),

        RefurbishStageVideo(
            id = "stage_10_edge_lamination",
            stageNumber = 10,
            titleAr = "شاشات Edge المنحنية: الكبس بالوسادة المطاطية الحمراء (Soft Pad Edge Lamination)",
            titleEn = "Curved Edge Display: Soft Red Rubber Pad Vacuum Lamination",
            titleFr = "Écran Incurvé Edge : Stratification avec tapis rouge souple",
            duration = "07:50",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "شرح عملية كبس الشاشات المنحنية داخل المكبس المفرغ باستخدام الوسادة المطاطية الحمراء/السوداء مرنة (Red Soft Pad) لمنع تشكل الضغط المتركز على الجوانب المائلة وتفادي كسر الـ OLED.",
            descriptionEn = "Vacuum laminating curved screens using soft red silicone pad to distribute pressure evenly and protect curved OLED edges.",
            descriptionFr = "Stratification sous vide des écrans incurvés avec tapis en silicone rouge souple pour répartir la pression.",
            tipsAr = listOf(
                "اخفض ضغط المكبس لشاشات الايدج ليصل إلى 0.25 - 0.35 MPa.",
                "استخدم الوسادة المطاطية الحمراء ذات المسام الدقيقة لامتصاص الصدمات.",
                "ضع الشاشة في الـ Autoclave لمدة 10 دقائق عند حرارة 50°C وضغط 0.6 MPa."
            ),
            tipsEn = listOf(
                "Reduce lamination pressure for Edge screens to 0.25 - 0.35 MPa.",
                "Always place red soft silicone pad over the curved glass during press cycle.",
                "Run Autoclave de-bubbler cycle for 10 minutes at 50°C and 0.6 MPa."
            ),
            tipsFr = listOf(
                "Réduisez la pression de plastification pour les écrans Edge à 0.25 - 0.35 MPa.",
                "Placez toujours le tapis en silicone rouge souple sur la vitre incurvée.",
                "Passez à l'autoclave pendant 10 minutes à 50°C et 0.6 MPa."
            ),
            toolsNeededAr = "وسادة مطاطية حمراء Red Edge Pad، مكبس تفريغ حاد، آلة Autoclave 0.6MPa",
            toolsNeededEn = "Red Edge soft silicone pad, vacuum laminator, Autoclave de-bubbler",
            toolsNeededFr = "Tapis silicone rouge Edge, plastifieuse sous vide, autoclave",
            recommendedTemp = "50°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "Edge"
        ),

        RefurbishStageVideo(
            id = "stage_11_polarizer",
            stageNumber = 11,
            titleAr = "استبدال فيلم البولاريزر (Polarizer Film) المخدوش للشاشات الفلات والايدج",
            titleEn = "Polarizer Film Replacement for Flat & Curved Displays",
            titleFr = "Remplacement du film polariseur pour écrans plats et incurvés",
            duration = "06:20",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "طريقة إزالة طبقة البولاريزر التالفة أو المخدوشة باستخدام شفرة التسخين الكهربائية، وتنظيف غراء البولاريزر الصلب، وتركيب فيلم مستقطب جديد لمنع البقع السوداء والمظهر الخافت.",
            descriptionEn = "Remove damaged polarizer film using heated blade tool, clean hard adhesive, and apply fresh polarizer sheet.",
            descriptionFr = "Retirez le film polariseur endommagé avec lame chauffante et posez un nouveau polariseur.",
            tipsAr = listOf(
                "استخدم شفرة التسخين عند 100°C وبزاوية مائلة 30 درجة لرفع البولاريزر بسهولة.",
                "امسح بقايا الغراء الصلب بسائل 8333 أو مذيب 530 مع قماش Microfiber.",
                "ركب البولاريزر الجديد برولر مطاطي محكم لمنع تكون أي حبات غبار تحت المستقطب."
            ),
            tipsEn = listOf(
                "Use heated blade at 100°C with 30° tilt angle to lift old polarizer.",
                "Clean stubborn hard glue with 8333 remover solvent and microfiber cloth.",
                "Apply new polarizer with rubber roller firmly from bottom to top."
            ),
            tipsFr = listOf(
                "Utilisez une lame chauffante à 100°C à un angle de 30°.",
                "Nettoyez la colle dure avec le solvant 8333 et un chiffon microfibre.",
                "Posez le nouveau polariseur avec un rouleau en caoutchouc."
            ),
            toolsNeededAr = "شفرة تسخين البولاريزر 100°C، فيلم Polarizer جديد، سائل 8333، رولر",
            toolsNeededEn = "Heated blade tool 100°C, fresh Polarizer sheet, 8333 liquid, roller",
            toolsNeededFr = "Lame chauffante 100°C, nouveau film polariseur, solvant 8333, rouleau",
            recommendedTemp = "95°C - 100°C",
            wireThickness = "غير مطلوب",
            targetScreenType = "All"
        ),

        // Dedicated LCD Screen Refurbishing Videos
        RefurbishStageVideo(
            id = "stage_12_lcd_refurbish",
            stageNumber = 12,
            titleAr = "شاشات LCD: طريقة تجديد الزجاج وحماية الإضاءة الخلفية (Backlight Protection)",
            titleEn = "LCD Screen Refurbishing: Backlight Protection & Solvent Caution",
            titleFr = "Rénovation Écran LCD : Protection du rétroéclairage et solvants",
            duration = "07:30",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "شرح كامل للتعامل مع شاشات IPS LCD (مثل Redmi, Poco, Realme, Infinix). التركيز على منع تسرب كحول التنظيف إلى الفلاتر العاكسة خلف الشاشة وتجنب البقع المائية في الإضاءة.",
            descriptionEn = "Complete guide for IPS LCD glass replacement. Preventing liquid solvent leakage into backlight reflectors and preventing moisture spots.",
            descriptionFr = "Guide complet pour écrans IPS LCD. Éviter les fuites de solvants dans le rétroéclairage.",
            tipsAr = listOf(
                "لا تستخدم المذيبات السائلة بكثرة في شاشات LCD، استخدم القليل جداً على قماش Microfiber.",
                "اضبط حرارة التسخين عند 75°C - 80°C فقط لتفادي اصفرار طبقة الإضاءة (Backlight Yellowing).",
                "إذا تسرب السائل للإضاءة، قم بتغيير ورقة الـ Backlight بحذر قبل الكبس."
            ),
            tipsEn = listOf(
                "Use minimal liquid cleaner on LCDs to prevent backlight spots.",
                "Keep heating separator temperature under 80°C to avoid backlight yellowing.",
                "If liquid penetrates backlight, replace the reflector sheet before lamination."
            ),
            tipsFr = listOf(
                "Utilisez très peu de solvant liquide sur LCD pour éviter les taches.",
                "Maintenez la température sous 80°C pour éviter le jaunissement du rétroéclairage.",
                "Si du liquide pénètre, remplacez la feuille de rétroéclairage."
            ),
            toolsNeededAr = "مسخن 75°C، سلك 0.03mm، قماش Microfiber شبه جاف، ورقة Backlight احتياطية",
            toolsNeededEn = "Separator at 75°C, 0.03mm wire, dry Microfiber, spare backlight sheet",
            toolsNeededFr = "Séparateur à 75°C, fil 0.03mm, microfibre sèche, feuille rétroéclairage",
            recommendedTemp = "75°C - 80°C",
            wireThickness = "0.03 mm",
            targetScreenType = "LCD"
        ),

        // Dedicated AMOLED Screen Refurbishing Videos
        RefurbishStageVideo(
            id = "stage_13_amoled_refurbish",
            stageNumber = 13,
            titleAr = "شاشات AMOLED: تفادي البقع السوداء وخطر كسر البيكسلات عند الفصل",
            titleEn = "AMOLED Displays: Avoiding Black Spots & Pixel Pressure Damage",
            titleFr = "Écrans AMOLED : Éviter les taches noires et la pression sur pixels",
            duration = "08:15",
            youtubeVideoId = "3S_oT631Psk",
            descriptionAr = "شاشات AMOLED المسطحة (مثل Samsung A-Series, Xiaomi AMOLED). كيفية فصل الزجاج بسلك 0.028mm وتفادي الضغط النقطي الذي يسبب تسرب الحبر أو ظهور البقع السوداء (Black Ink Spots).",
            descriptionEn = "Flat AMOLED glass replacement tutorial. How to use 0.028mm wire and avoid pinpoint pressure causing OLED ink bleeding or black spots.",
            descriptionFr = "Remplacement de vitre AMOLED plat. Utilisation du fil 0.028mm pour éviter les taches noires.",
            tipsAr = listOf(
                "شاشات AMOLED مرنة ولا تحتوي على backlight، يمكنك استخدام كحول IPA 99% بأمان للتنظيف.",
                "احرص على عدم زلق السلك تحت طبقة الموديل الأصلية بل اجعله يلامس الزجاج فقط.",
                "استخدم ضغط كبس متوازن 0.35 MPa في آلة اللامينيشن."
            ),
            tipsEn = listOf(
                "AMOLED panels have no backlight layer, so IPA 99% solvent cleaning is 100% safe.",
                "Keep wire strictly hugging top glass layer to avoid tearing sub-pixels.",
                "Set lamination pressure steadily at 0.35 MPa."
            ),
            tipsFr = listOf(
                "Les dalles AMOLED n'ont pas de rétroéclairage, l'IPA 99% est sans danger.",
                "Gardez le fil plaqué contre la vitre supérieure.",
                "Réglez la pression de plastification à 0.35 MPa."
            ),
            toolsNeededAr = "سخان Vacuum 85°C، سلك مكروم 0.028mm، كحول IPA 99%، دريل OCA",
            toolsNeededEn = "Vacuum separator 85°C, 0.028mm wire, IPA 99%, OCA remover drill",
            toolsNeededFr = "Séparateur 85°C, fil 0.028mm, IPA 99%, moteur OCA",
            recommendedTemp = "85°C",
            wireThickness = "0.028 mm",
            targetScreenType = "AMOLED"
        ),

        // Dedicated Super AMOLED Screen Refurbishing Videos
        RefurbishStageVideo(
            id = "stage_14_super_amoled",
            stageNumber = 14,
            titleAr = "شاشات Super AMOLED: التعامل مع الشاشات الفائقة الرقة واللمس المدمج",
            titleEn = "Super AMOLED Displays: Ultra-Thin Panel & Integrated Digitizer Handling",
            titleFr = "Écrans Super AMOLED : Dalles ultra-fines et tactile intégré",
            duration = "09:40",
            youtubeVideoId = "dQw4w9WgXcQ",
            descriptionAr = "دليل تجديد شاشات Super AMOLED الفاخرة (مثل هواتف Samsung S & Note Series). الشاشة رقيقة جداً ومدمجة مع الحساس، وتتطلب سلكاً ناعماً 0.025mm وضبطاً دقيقاً للغاية للحرارة والكبس.",
            descriptionEn = "Premium Super AMOLED refurbishing (Samsung S & Note series). Extremely thin panel requiring 0.025mm fine wire and precise heat/pressure control.",
            descriptionFr = "Rénovation Super AMOLED haut de gamme (Samsung S & Note). Dalle ultra-fine nécessitant un fil 0.025mm.",
            tipsAr = listOf(
                "استخدم سلكاً متطوراً بسمك 0.025mm أو 0.020mm لتقليل الاحتكاك مع البيكسلات.",
                "اضبط حرارة الفصل عند 85°C - 90°C لجعل غراء الميكرو يذوب بسلاسة.",
                "في آلة تفريغ الفقاعات (Autoclave)، استخدم حرارة 50°C وضغط 0.55 MPa لمدة 6 دقائق."
            ),
            tipsEn = listOf(
                "Use ultra-thin 0.025mm wire to minimize friction against thin OLED substrate.",
                "Heat separator to 85°C - 90°C so micro-OCA melts cleanly.",
                "Autoclave de-bubbler settings: 50°C at 0.55 MPa for 6 minutes."
            ),
            tipsFr = listOf(
                "Utilisez un fil ultra-fin de 0.025mm pour réduire la friction.",
                "Chauffez le séparateur à 85°C - 90°C pour faire fondre la micro-colle.",
                "Autoclave : 50°C à 0.55 MPa pendant 6 minutes."
            ),
            toolsNeededAr = "سخان شاشات دقيق 90°C، سلك فولاذ ذهبي 0.025mm، وسادة كبس Super AMOLED",
            toolsNeededEn = "Precision separator 90°C, 0.025mm gold wire, Super AMOLED press pad",
            toolsNeededFr = "Séparateur de précision 90°C, fil d'or 0.025mm, tapis Super AMOLED",
            recommendedTemp = "85°C - 90°C",
            wireThickness = "0.025 mm",
            targetScreenType = "Super AMOLED"
        )
    )
}
