package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.EquipmentCatalogData
import com.example.data.model.EquipmentCategory
import com.example.data.model.EquipmentProduct
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

@Composable
fun ManageProductsDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val products = EquipmentCatalogData.products

    var productToEdit by remember { mutableStateOf<EquipmentProduct?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🛠️ إدارة قائمة منتجات المتجر",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_add_new_product_modal"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة منتج", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            EquipmentCatalogData.resetToDefaults(context)
                            Toast.makeText(context, "تمت إعادة المنتجات الافتراضية 🔄", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إعادة الافتراضي", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "المنتجات الحالية (${products.size}):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Products List
                products.forEach { product ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (product.imageUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = product.imageUrl,
                                        contentDescription = product.nameAr,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                } else {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                        modifier = Modifier.size(46.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(product.emoji, fontSize = 24.sp)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = product.nameAr,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${product.priceDzd} د.ج | ${product.category.titleAr}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            Row {
                                IconButton(
                                    onClick = { productToEdit = product },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        EquipmentCatalogData.deleteProduct(context, product.id)
                                        Toast.makeText(context, "تم حذف المنتج", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.Red,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog || productToEdit != null) {
        AddEditProductDialog(
            existingProduct = productToEdit,
            onDismiss = {
                showAddDialog = false
                productToEdit = null
            }
        )
    }
}

@Composable
fun AddEditProductDialog(
    existingProduct: EquipmentProduct?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var nameAr by remember { mutableStateOf(existingProduct?.nameAr ?: "") }
    var selectedCategory by remember { mutableStateOf(existingProduct?.category ?: EquipmentCategory.MACHINES) }
    var priceDzdText by remember { mutableStateOf(existingProduct?.priceDzd?.toString() ?: "") }
    var origPriceDzdText by remember { mutableStateOf(existingProduct?.originalPriceDzd?.toString() ?: "") }
    var badgeAr by remember { mutableStateOf(existingProduct?.badgeAr ?: "متوفر 🔥") }
    var emoji by remember { mutableStateOf(existingProduct?.emoji ?: "⚙️") }
    var imageUrl by remember { mutableStateOf(existingProduct?.imageUrl ?: "") }
    var descriptionAr by remember { mutableStateOf(existingProduct?.descriptionAr ?: "") }
    var specsArText by remember { mutableStateOf(existingProduct?.specsAr?.joinToString(", ") ?: "") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val localPath = saveProductImageToInternalStorage(context, uri)
            imageUrl = localPath
            Toast.makeText(context, "تم رفع واختيار صورة المنتج 🖼️", Toast.LENGTH_SHORT).show()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existingProduct != null) "تعديل بيانات المنتج ✏️" else "إضافة منتج جديد للمتجر ➕",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Product Image Section
                Text(
                    text = "صورة المنتج 🖼️:",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                if (imageUrl.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        AsyncImage(
                            model = imageUrl,
                            contentDescription = "Product Image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth()
                        )
                        IconButton(
                            onClick = { imageUrl = "" },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(32.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.6f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove Image",
                                    tint = Color.White,
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_pick_product_photo"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار من المعرض 🖼️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Image URL Input
                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = { Text("أو ضع رابط الصورة المباشر (URL)") },
                    placeholder = { Text("https://example.com/product_image.jpg") },
                    modifier = Modifier.fillMaxWidth().testTag("input_product_image_url"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Name Arabic
                OutlinedTextField(
                    value = nameAr,
                    onValueChange = { nameAr = it },
                    label = { Text("اسم المنتج (بالعربية)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_product_name_ar"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Selector
                Text("اختر القسم / الفئة:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        EquipmentCategory.MACHINES,
                        EquipmentCategory.CONSUMABLES,
                        EquipmentCategory.OCA_GLASS,
                        EquipmentCategory.TOOLS
                    ).forEach { cat ->
                        val isSel = selectedCategory == cat
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedCategory = cat }
                        ) {
                            Text(
                                text = cat.titleAr,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Price DZD
                    OutlinedTextField(
                        value = priceDzdText,
                        onValueChange = { priceDzdText = it },
                        label = { Text("السعر (د.ج)") },
                        modifier = Modifier.weight(1f).testTag("input_product_price"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Original Price DZD
                    OutlinedTextField(
                        value = origPriceDzdText,
                        onValueChange = { origPriceDzdText = it },
                        label = { Text("قبل الخصم (اختياري)") },
                        modifier = Modifier.weight(1f).testTag("input_product_orig_price"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Emoji
                    OutlinedTextField(
                        value = emoji,
                        onValueChange = { emoji = it },
                        label = { Text("الإيموجي") },
                        modifier = Modifier.weight(0.35f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Badge AR
                    OutlinedTextField(
                        value = badgeAr,
                        onValueChange = { badgeAr = it },
                        label = { Text("الشارة (Badge)") },
                        modifier = Modifier.weight(0.65f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                OutlinedTextField(
                    value = descriptionAr,
                    onValueChange = { descriptionAr = it },
                    label = { Text("وصف مختصر للمنتج") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Specs
                OutlinedTextField(
                    value = specsArText,
                    onValueChange = { specsArText = it },
                    label = { Text("المواصفات (افصل بينها بفاصلة ,)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Save Button
                Button(
                    onClick = {
                        if (nameAr.isBlank() || priceDzdText.isBlank()) {
                            Toast.makeText(context, "الرجاء إدخال اسم المنتوج والسعر", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val priceInt = priceDzdText.trim().toIntOrNull() ?: 1000
                        val origPriceInt = origPriceDzdText.trim().toIntOrNull()
                        val specsList = specsArText.split(",").map { it.trim() }.filter { it.isNotBlank() }

                        val product = EquipmentProduct(
                            id = existingProduct?.id ?: "custom_${UUID.randomUUID().toString().take(8)}",
                            nameAr = nameAr.trim(),
                            nameEn = existingProduct?.nameEn ?: nameAr.trim(),
                            nameFr = existingProduct?.nameFr ?: nameAr.trim(),
                            category = selectedCategory,
                            priceDzd = priceInt,
                            originalPriceDzd = origPriceInt,
                            badgeAr = badgeAr.ifBlank { "جديد 🔥" },
                            badgeEn = existingProduct?.badgeEn ?: "New 🔥",
                            badgeFr = existingProduct?.badgeFr ?: "Nouveau 🔥",
                            descriptionAr = descriptionAr.ifBlank { nameAr.trim() },
                            descriptionEn = existingProduct?.descriptionEn ?: nameAr.trim(),
                            descriptionFr = existingProduct?.descriptionFr ?: nameAr.trim(),
                            specsAr = specsList.ifEmpty { listOf("جودة ممتازة") },
                            specsEn = existingProduct?.specsEn ?: listOf("High Quality"),
                            specsFr = existingProduct?.specsFr ?: listOf("Haute Qualité"),
                            emoji = emoji.ifBlank { "⚙️" },
                            imageUrl = imageUrl.trim(),
                            isHotDeal = true
                        )

                        if (existingProduct != null) {
                            EquipmentCatalogData.updateProduct(context, product)
                            Toast.makeText(context, "تم حفظ التعديلات ✏️", Toast.LENGTH_SHORT).show()
                        } else {
                            EquipmentCatalogData.addProduct(context, product)
                            Toast.makeText(context, "تمت إضافة المنتج بنجاح ➕", Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

fun saveProductImageToInternalStorage(context: android.content.Context, uri: Uri): String {
    return try {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return uri.toString()
        val imagesDir = File(context.filesDir, "product_images").apply { mkdirs() }
        val file = File(imagesDir, "prod_img_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { outputStream ->
            inputStream.copyTo(outputStream)
        }
        file.absolutePath
    } catch (e: Exception) {
        e.printStackTrace()
        uri.toString()
    }
}
