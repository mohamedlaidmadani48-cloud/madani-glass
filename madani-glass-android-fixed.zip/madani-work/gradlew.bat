@echo off
if not exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  echo Gradle Wrapper JAR is missing. Open this project in Android Studio and regenerate the wrapper, or install Gradle and run: gradle wrapper
  exit /b 1
)
java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
