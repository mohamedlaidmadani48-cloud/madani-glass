package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "phones")
data class PhoneEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val brand: String,
    val modelName: String,
    val modelCode: String,
    val screenSizeInch: Double,
    val screenType: String,
    val compatibilityGroupId: String,
    val compatibleModels: String,
    val glassType: String,
    val cameraCutout: String, // V-Notch, U-Notch, Center Punch Hole, Corner Punch Hole, Notch, Dynamic Island, Curved
    val separationTempCelsius: Int = 85,
    val wireSizeMm: String = "0.03 mm",
    val ocaType: String = "175µm OCA Premounted",
    val technicianNotes: String = "",
    val userNotes: String = "",
    val isFavorite: Boolean = false
)
