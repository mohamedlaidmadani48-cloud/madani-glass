package com.example.ui.language

object Strings {
    fun get(key: String, language: AppLanguage = LanguageState.currentLanguage.value): String {
        val stringsMap = mapOf(
            "app_title" to mapOf(
                AppLanguage.ARABIC to "مدني جلاس | MADANI GLASS",
                AppLanguage.ENGLISH to "Madani Glass Refurbish",
                AppLanguage.FRENCH to "Madani Glass Rénovation"
            ),
            "subtitle" to mapOf(
                AppLanguage.ARABIC to "دليل التوافقات والتجديد لفنيي الصيانة",
                AppLanguage.ENGLISH to "Screen & Glass Compatibility Reference",
                AppLanguage.FRENCH to "Guide de compatibilité écran & vitres"
            ),
            "search_placeholder" to mapOf(
                AppLanguage.ARABIC to "ابحث باسم الهاتف، الموديل أو الماركة (مثال: A12, Note 10)...",
                AppLanguage.ENGLISH to "Search by phone name, model code or brand (e.g. A12)...",
                AppLanguage.FRENCH to "Rechercher par nom, code modèle ou marque (ex: A12)..."
            ),
            "all" to mapOf(
                AppLanguage.ARABIC to "الكل",
                AppLanguage.ENGLISH to "All",
                AppLanguage.FRENCH to "Tous"
            ),
            "favorites" to mapOf(
                AppLanguage.ARABIC to "المفضلة",
                AppLanguage.ENGLISH to "Favorites",
                AppLanguage.FRENCH to "Favoris"
            ),
            "screen_size" to mapOf(
                AppLanguage.ARABIC to "مقاس الزجاج",
                AppLanguage.ENGLISH to "Glass Size",
                AppLanguage.FRENCH to "Taille de la vitre"
            ),
            "screen_type" to mapOf(
                AppLanguage.ARABIC to "نوع الشاشة",
                AppLanguage.ENGLISH to "Screen Type",
                AppLanguage.FRENCH to "Type d'écran"
            ),
            "compatible_models" to mapOf(
                AppLanguage.ARABIC to "الهواتف المتوافقة 100% مع هذا الزجاج:",
                AppLanguage.ENGLISH to "100% Compatible Models for this Glass:",
                AppLanguage.FRENCH to "Modèles 100% compatibles avec cette vitre :"
            ),
            "glass_details" to mapOf(
                AppLanguage.ARABIC to "مواصفات زجاج الغيار",
                AppLanguage.ENGLISH to "Glass Replacement Specs",
                AppLanguage.FRENCH to "Spécifications de la vitre"
            ),
            "separation_temp" to mapOf(
                AppLanguage.ARABIC to "حرارة مقبض الفك",
                AppLanguage.ENGLISH to "Separation Heating Temp",
                AppLanguage.FRENCH to "Température de séparation"
            ),
            "wire_gauge" to mapOf(
                AppLanguage.ARABIC to "سلك الفك الموصى به",
                AppLanguage.ENGLISH to "Wire Gauge Size",
                AppLanguage.FRENCH to "Taille du fil molybdène"
            ),
            "oca_type" to mapOf(
                AppLanguage.ARABIC to "نوع فيلم OCA",
                AppLanguage.ENGLISH to "OCA Film Type",
                AppLanguage.FRENCH to "Type de film OCA"
            ),
            "camera_notch" to mapOf(
                AppLanguage.ARABIC to "قصة الكاميرا",
                AppLanguage.ENGLISH to "Camera Cutout",
                AppLanguage.FRENCH to "Découpe caméra"
            ),
            "technician_notes" to mapOf(
                AppLanguage.ARABIC to "ملاحظات الفني",
                AppLanguage.ENGLISH to "Technical Notes",
                AppLanguage.FRENCH to "Notes techniques"
            ),
            "user_notes" to mapOf(
                AppLanguage.ARABIC to "ملاحظاتك الخاصة للموديل",
                AppLanguage.ENGLISH to "Your Shop Notes",
                AppLanguage.FRENCH to "Vos notes d'atelier"
            ),
            "add_user_notes" to mapOf(
                AppLanguage.ARABIC to "تعديل ملاحظات الورشة",
                AppLanguage.ENGLISH to "Edit Shop Notes",
                AppLanguage.FRENCH to "Modifier les notes"
            ),
            "save" to mapOf(
                AppLanguage.ARABIC to "حفظ",
                AppLanguage.ENGLISH to "Save",
                AppLanguage.FRENCH to "Enregistrer"
            ),
            "cancel" to mapOf(
                AppLanguage.ARABIC to "إلغاء",
                AppLanguage.ENGLISH to "Cancel",
                AppLanguage.FRENCH to "Annuler"
            ),
            "refurbish_calculator" to mapOf(
                AppLanguage.ARABIC to "حاسبة حرارة وسلك الفك",
                AppLanguage.ENGLISH to "Heat & Wire Guide",
                AppLanguage.FRENCH to "Guide chauffe & fil"
            ),
            "add_device" to mapOf(
                AppLanguage.ARABIC to "إضافة هاتف جديد",
                AppLanguage.ENGLISH to "Add New Phone",
                AppLanguage.FRENCH to "Ajouter un téléphone"
            ),
            "brand" to mapOf(
                AppLanguage.ARABIC to "الماركة",
                AppLanguage.ENGLISH to "Brand",
                AppLanguage.FRENCH to "Marque"
            ),
            "model_name" to mapOf(
                AppLanguage.ARABIC to "اسم الموديل",
                AppLanguage.ENGLISH to "Model Name",
                AppLanguage.FRENCH to "Nom du modèle"
            ),
            "model_code" to mapOf(
                AppLanguage.ARABIC to "كود الموديل (e.g. SM-A125F)",
                AppLanguage.ENGLISH to "Model Code (e.g. SM-A125F)",
                AppLanguage.FRENCH to "Code modèle (ex: SM-A125F)"
            ),
            "no_results" to mapOf(
                AppLanguage.ARABIC to "لم يتم العثور على أجهزة مطابقة للبحث",
                AppLanguage.ENGLISH to "No matching phone models found",
                AppLanguage.FRENCH to "Aucun modèle correspondant trouvé"
            ),
            "temp_guide_title" to mapOf(
                AppLanguage.ARABIC to "دليل حرارة الفك وسلك الموليبلدنيوم",
                AppLanguage.ENGLISH to "Separator Temp & Molybdenum Wire Guide",
                AppLanguage.FRENCH to "Guide Température & Fil Molybdène"
            ),
            "lcd_guide" to mapOf(
                AppLanguage.ARABIC to "شاشات LCD / IPS: حرارة 75°C - 85°C | سلك 0.03mm إلى 0.05mm",
                AppLanguage.ENGLISH to "LCD / IPS screens: Temp 75°C - 85°C | Wire 0.03mm - 0.05mm",
                AppLanguage.FRENCH to "Écrans LCD / IPS : Temp 75°C - 85°C | Fil 0.03mm - 0.05mm"
            ),
            "amoled_guide" to mapOf(
                AppLanguage.ARABIC to "شاشات AMOLED / OLED: حرارة 80°C - 90°C | سلك 0.03mm رفيع جداً",
                AppLanguage.ENGLISH to "AMOLED / OLED screens: Temp 80°C - 90°C | Wire 0.03mm ultra-thin",
                AppLanguage.FRENCH to "Écrans AMOLED / OLED : Temp 80°C - 90°C | Fil 0.03mm ultra-fin"
            ),
            "curved_guide" to mapOf(
                AppLanguage.ARABIC to "الشاشات المنحنية Edge: حرارة 88°C - 95°C | سلك 0.028mm - 0.03mm مع مجفف الفريزر",
                AppLanguage.ENGLISH to "Curved Edge screens: Temp 88°C - 95°C | Wire 0.028mm - 0.03mm with freezing line",
                AppLanguage.FRENCH to "Écrans Incurvés Edge : Temp 88°C - 95°C | Fil 0.028mm - 0.03mm avec congélateur"
            ),
            "inch_unit" to mapOf(
                AppLanguage.ARABIC to "إنش",
                AppLanguage.ENGLISH to "inch",
                AppLanguage.FRENCH to "pouce"
            ),
            "group_id" to mapOf(
                AppLanguage.ARABIC to "معرف مجموعة التوافق",
                AppLanguage.ENGLISH to "Compatibility Group ID",
                AppLanguage.FRENCH to "ID du groupe de compatibilité"
            ),
            "edit_compatibility" to mapOf(
                AppLanguage.ARABIC to "تعديل التوافقات والمواصفات",
                AppLanguage.ENGLISH to "Edit Compatibility & Specs",
                AppLanguage.FRENCH to "Modifier compatibilités & spécifications"
            ),
            "delete_device" to mapOf(
                AppLanguage.ARABIC to "حذف الجهاز",
                AppLanguage.ENGLISH to "Delete Device",
                AppLanguage.FRENCH to "Supprimer l'appareil"
            ),
            "delete_confirm_title" to mapOf(
                AppLanguage.ARABIC to "تأكيد الحذف",
                AppLanguage.ENGLISH to "Confirm Deletion",
                AppLanguage.FRENCH to "Confirmer la suppression"
            ),
            "delete_confirm_msg" to mapOf(
                AppLanguage.ARABIC to "هل أنت تأكد من حذف بيانات هذا الجهاز والتوافقات الخاصة به؟",
                AppLanguage.ENGLISH to "Are you sure you want to delete this device and its compatibility data?",
                AppLanguage.FRENCH to "Êtes-vous sûr de vouloir supprimer cet appareil et ses données ?"
            ),
            "video_tutorials" to mapOf(
                AppLanguage.ARABIC to "فيديوهات تغيير الزجاج (الباغة)",
                AppLanguage.ENGLISH to "Glass Refurbish Videos",
                AppLanguage.FRENCH to "Tutoriels Changement Vitre"
            ),
            "refurbishing_stages" to mapOf(
                AppLanguage.ARABIC to "مراحل تغيير وحماية الزجاج خطوة بخطوة",
                AppLanguage.ENGLISH to "Step-by-Step Screen Glass Refurbishing",
                AppLanguage.FRENCH to "Étape par étape du remplacement de la vitre"
            ),
            "watch_tutorial" to mapOf(
                AppLanguage.ARABIC to "تشغيل الفيديو التعليمي",
                AppLanguage.ENGLISH to "Play Tutorial Video",
                AppLanguage.FRENCH to "Lancer la vidéo"
            ),
            "close_player" to mapOf(
                AppLanguage.ARABIC to "إغلاق المشغل",
                AppLanguage.ENGLISH to "Close Video Player",
                AppLanguage.FRENCH to "Fermer le lecteur"
            ),
            "stage_number" to mapOf(
                AppLanguage.ARABIC to "المرحلة",
                AppLanguage.ENGLISH to "Stage",
                AppLanguage.FRENCH to "Étape"
            ),
            "pro_tips" to mapOf(
                AppLanguage.ARABIC to "💡 نصائح وتقنيات دقيقة:",
                AppLanguage.ENGLISH to "💡 Pro Technician Tips:",
                AppLanguage.FRENCH to "💡 Astuces de technicien :"
            ),
            "watch_model_guide" to mapOf(
                AppLanguage.ARABIC to "🎥 فيديو تعليمي لتغيير زجاج هذا الموديل",
                AppLanguage.ENGLISH to "🎥 Watch Glass Repair Video for this model",
                AppLanguage.FRENCH to "🎥 Voir la vidéo de remplacement"
            ),
            "store_title" to mapOf(
                AppLanguage.ARABIC to "متجر عتاد تغيير الزجاج",
                AppLanguage.ENGLISH to "Glass Refurbish Equipment Store",
                AppLanguage.FRENCH to "Magasin d'Équipement de Reconditionnement"
            ),
            "store_subtitle" to mapOf(
                AppLanguage.ARABIC to "أجود السخانات، مكابس الـ OCA ومستلزمات الصيانة",
                AppLanguage.ENGLISH to "Quality Separators, Laminators & Repair Tools",
                AppLanguage.FRENCH to "Séparateurs, plastifieuses et outils de qualité"
            ),
            "nav_compatibility" to mapOf(
                AppLanguage.ARABIC to "دليل التوافقات",
                AppLanguage.ENGLISH to "Compatibility Guide",
                AppLanguage.FRENCH to "Guide Compatibilité"
            ),
            "nav_store" to mapOf(
                AppLanguage.ARABIC to "متجر العتاد",
                AppLanguage.ENGLISH to "Equipment Store",
                AppLanguage.FRENCH to "Boutique العتاد"
            ),
            "add_to_cart" to mapOf(
                AppLanguage.ARABIC to "إضافة للسلة",
                AppLanguage.ENGLISH to "Add to Cart",
                AppLanguage.FRENCH to "Ajouter au panier"
            ),
            "order_now" to mapOf(
                AppLanguage.ARABIC to "طلب مباشر",
                AppLanguage.ENGLISH to "Order Now",
                AppLanguage.FRENCH to "Commander"
            ),
            "cart_title" to mapOf(
                AppLanguage.ARABIC to "سلة طلبات العتاد",
                AppLanguage.ENGLISH to "Equipment Order Cart",
                AppLanguage.FRENCH to "Panier de commande"
            ),
            "order_via_whatsapp" to mapOf(
                AppLanguage.ARABIC to "ارسال الطلب عبر الواتساب",
                AppLanguage.ENGLISH to "Order via WhatsApp",
                AppLanguage.FRENCH to "Commander via WhatsApp"
            ),
            "currency_dzd" to mapOf(
                AppLanguage.ARABIC to "د.ج",
                AppLanguage.ENGLISH to "DZD",
                AppLanguage.FRENCH to "DZD"
            ),
            "in_stock" to mapOf(
                AppLanguage.ARABIC to "متوفر في المخزن",
                AppLanguage.ENGLISH to "In Stock",
                AppLanguage.FRENCH to "En stock"
            ),
            "fast_delivery" to mapOf(
                AppLanguage.ARABIC to "توصيل سريع 58 ولاية",
                AppLanguage.ENGLISH to "Fast Nationwide Shipping",
                AppLanguage.FRENCH to "Livraison rapide 58 wilayas"
            ),
            "social_channels_title" to mapOf(
                AppLanguage.ARABIC to "تواصل وقنوات التعليم (مداني غلاس)",
                AppLanguage.ENGLISH to "Madani Glass Social & Tutorials",
                AppLanguage.FRENCH to "Canaux et Tutoriels Madani Glass"
            ),
            "social_channels_sub" to mapOf(
                AppLanguage.ARABIC to "تابع شروحات الصيانة وتغيير الشاشات عبر منصاتنا",
                AppLanguage.ENGLISH to "Watch screen repair tutorials & updates",
                AppLanguage.FRENCH to "Suivez nos tutoriels et nouveautés"
            ),
            "facebook_name" to mapOf(
                AppLanguage.ARABIC to "صفحة الفايسبوك",
                AppLanguage.ENGLISH to "Facebook Page",
                AppLanguage.FRENCH to "Page Facebook"
            ),
            "tiktok_name" to mapOf(
                AppLanguage.ARABIC to "حساب التيكتوك",
                AppLanguage.ENGLISH to "TikTok Channel",
                AppLanguage.FRENCH to "Compte TikTok"
            ),
            "youtube_name" to mapOf(
                AppLanguage.ARABIC to "قناة اليوتيوب",
                AppLanguage.ENGLISH to "YouTube Channel",
                AppLanguage.FRENCH to "Chaîne YouTube"
            ),
            "follow_us" to mapOf(
                AppLanguage.ARABIC to "متابعة",
                AppLanguage.ENGLISH to "Follow",
                AppLanguage.FRENCH to "Suivre"
            ),
            "edit_social_links" to mapOf(
                AppLanguage.ARABIC to "تعديل حسابات التواصل",
                AppLanguage.ENGLISH to "Edit Social Accounts",
                AppLanguage.FRENCH to "Modifier les comptes sociaux"
            ),
            "facebook_url" to mapOf(
                AppLanguage.ARABIC to "رابط حساب الفايسبوك",
                AppLanguage.ENGLISH to "Facebook Account Link",
                AppLanguage.FRENCH to "Lien compte Facebook"
            ),
            "tiktok_url" to mapOf(
                AppLanguage.ARABIC to "رابط حساب التيكتوك",
                AppLanguage.ENGLISH to "TikTok Account Link",
                AppLanguage.FRENCH to "Lien compte TikTok"
            ),
            "youtube_url" to mapOf(
                AppLanguage.ARABIC to "رابط قناة اليوتيوب",
                AppLanguage.ENGLISH to "YouTube Channel Link",
                AppLanguage.FRENCH to "Lien chaîne YouTube"
            ),
            "save_changes" to mapOf(
                AppLanguage.ARABIC to "حفظ التغييرات",
                AppLanguage.ENGLISH to "Save Changes",
                AppLanguage.FRENCH to "Enregistrer"
            ),
            "links_saved_success" to mapOf(
                AppLanguage.ARABIC to "تم حفظ روابط الحسابات بنجاح ✅",
                AppLanguage.ENGLISH to "Social links saved successfully ✅",
                AppLanguage.FRENCH to "Liens enregistrés avec succès ✅"
            ),
            "edit_app_info" to mapOf(
                AppLanguage.ARABIC to "تعديل بيانات التطبيق",
                AppLanguage.ENGLISH to "Edit App Details",
                AppLanguage.FRENCH to "Modifier l'application"
            ),
            "app_title_label" to mapOf(
                AppLanguage.ARABIC to "اسم / عنوان التطبيق",
                AppLanguage.ENGLISH to "App Name / Title",
                AppLanguage.FRENCH to "Nom de l'application"
            ),
            "app_subtitle_label" to mapOf(
                AppLanguage.ARABIC to "الوصف الفرعي / الشعار",
                AppLanguage.ENGLISH to "Subtitle / Tagline",
                AppLanguage.FRENCH to "Sous-titre / Slogan"
            ),
            "contact_phone_label" to mapOf(
                AppLanguage.ARABIC to "رقم الهاتف والطلبات",
                AppLanguage.ENGLISH to "Contact Phone & Orders",
                AppLanguage.FRENCH to "Téléphone & Commandes"
            ),
            "store_address_label" to mapOf(
                AppLanguage.ARABIC to "عنوان ورشة الصيانة / الولايات",
                AppLanguage.ENGLISH to "Workshop Address / Coverage",
                AppLanguage.FRENCH to "Adresse de l'atelier"
            ),
            "announcement_banner_label" to mapOf(
                AppLanguage.ARABIC to "شريط التنبيهات والإعلانات",
                AppLanguage.ENGLISH to "Announcement Banner Text",
                AppLanguage.FRENCH to "Bannière d'annonces"
            ),
            "app_info_saved_success" to mapOf(
                AppLanguage.ARABIC to "تم تحديث وحفظ بيانات التطبيق بنجاح ✅",
                AppLanguage.ENGLISH to "App details updated successfully ✅",
                AppLanguage.FRENCH to "Application mise à jour avec succès ✅"
            ),
            "qr_scanner_title" to mapOf(
                AppLanguage.ARABIC to "ماسح QR للتوافق السريع",
                AppLanguage.ENGLISH to "QR Glass Finder & Scanner",
                AppLanguage.FRENCH to "Scanner QR Verre & Compatibilité"
            ),
            "qr_scanner_sub" to mapOf(
                AppLanguage.ARABIC to "امسح كود QR للهاتف لمعرفة نوع الزجاج المقترح والتوافقات فوراً",
                AppLanguage.ENGLISH to "Scan phone QR code to find compatible screen glass and OCA immediately",
                AppLanguage.FRENCH to "Scannez le QR code pour trouver le verre compatible instantanément"
            ),
            "scan_or_type_qr" to mapOf(
                AppLanguage.ARABIC to "مسح بالتوجيه أو إدخال كود QR",
                AppLanguage.ENGLISH to "Camera Scan or Enter QR Code",
                AppLanguage.FRENCH to "Scanner par Caméra ou Entrer Code"
            ),
            "qr_code_placeholder" to mapOf(
                AppLanguage.ARABIC to "رمز QR أو اسم موديل الهاتف...",
                AppLanguage.ENGLISH to "QR code or phone model...",
                AppLanguage.FRENCH to "Code QR ou modèle de téléphone..."
            ),
            "scan_result_title" to mapOf(
                AppLanguage.ARABIC to "نتائج الفحص واقتراحات الزجاج",
                AppLanguage.ENGLISH to "Scan Results & Glass Suggestions",
                AppLanguage.FRENCH to "Résultats et Verres Compatibles"
            ),
            "glass_suggestions_title" to mapOf(
                AppLanguage.ARABIC to "اقتراحات الزجاج والتوافقات المتاحة:",
                AppLanguage.ENGLISH to "Suggested Compatible Glasses & OCA:",
                AppLanguage.FRENCH to "Verres et OCA Compatibles Suggérés:"
            ),
            "quick_sample_qrs" to mapOf(
                AppLanguage.ARABIC to "عينات رموز QR سريعة للبحث:",
                AppLanguage.ENGLISH to "Quick QR Code Samples:",
                AppLanguage.FRENCH to "Échantillons QR Rapides:"
            ),
            "subscription_hub_title" to mapOf(
                AppLanguage.ARABIC to "خطط الاشتراكات المميزة",
                AppLanguage.ENGLISH to "Premium Subscriptions Hub",
                AppLanguage.FRENCH to "Abonnements Premium"
            ),
            "monthly_plan" to mapOf(
                AppLanguage.ARABIC to "الاشتراك الشهري",
                AppLanguage.ENGLISH to "Monthly Plan",
                AppLanguage.FRENCH to "Abonnement Mensuel"
            ),
            "yearly_plan" to mapOf(
                AppLanguage.ARABIC to "الاشتراك السنوي (توفير أكبر)",
                AppLanguage.ENGLISH to "Yearly Plan (Best Value)",
                AppLanguage.FRENCH to "Abonnement Annuel (Meilleure Offre)"
            ),
            "payment_methods" to mapOf(
                AppLanguage.ARABIC to "طرق الدفع المتاحة",
                AppLanguage.ENGLISH to "Payment Methods",
                AppLanguage.FRENCH to "Moyens de Paiement"
            ),
            "copy_copied" to mapOf(
                AppLanguage.ARABIC to "تم النسخ بنجاح 📋",
                AppLanguage.ENGLISH to "Copied to clipboard 📋",
                AppLanguage.FRENCH to "Copié avec succès 📋"
            ),
            "confirm_send_receipt" to mapOf(
                AppLanguage.ARABIC to "إرسال وصل الدفع والتأكيد عبر واتساب",
                AppLanguage.ENGLISH to "Send Receipt & Confirm via WhatsApp",
                AppLanguage.FRENCH to "Envoyer Reçu et Confirmer via WhatsApp"
            )
        )

        return stringsMap[key]?.get(language) ?: stringsMap[key]?.get(AppLanguage.ENGLISH) ?: key
    }
}
