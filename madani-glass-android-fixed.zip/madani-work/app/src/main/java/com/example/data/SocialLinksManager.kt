package com.example.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

data class SocialLinks(
    val facebookUrl: String = "https://www.facebook.com/madaniglass",
    val tiktokUrl: String = "https://www.tiktok.com/@madaniglass",
    val youtubeUrl: String = "https://www.youtube.com/@madaniglass"
)

object SocialLinksManager {
    private const val PREFS_NAME = "madani_glass_social_prefs"
    private const val KEY_FB = "facebook_url"
    private const val KEY_TIKTOK = "tiktok_url"
    private const val KEY_YOUTUBE = "youtube_url"

    val currentLinks = mutableStateOf(SocialLinks())

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val fb = prefs.getString(KEY_FB, "https://www.facebook.com/madaniglass") ?: "https://www.facebook.com/madaniglass"
        val tiktok = prefs.getString(KEY_TIKTOK, "https://www.tiktok.com/@madaniglass") ?: "https://www.tiktok.com/@madaniglass"
        val youtube = prefs.getString(KEY_YOUTUBE, "https://www.youtube.com/@madaniglass") ?: "https://www.youtube.com/@madaniglass"

        currentLinks.value = SocialLinks(
            facebookUrl = fb,
            tiktokUrl = tiktok,
            youtubeUrl = youtube
        )
    }

    fun saveLinks(context: Context, facebook: String, tiktok: String, youtube: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cleanFb = if (facebook.isBlank()) "https://www.facebook.com/madaniglass" else facebook.trim()
        val cleanTiktok = if (tiktok.isBlank()) "https://www.tiktok.com/@madaniglass" else tiktok.trim()
        val cleanYoutube = if (youtube.isBlank()) "https://www.youtube.com/@madaniglass" else youtube.trim()

        prefs.edit()
            .putString(KEY_FB, cleanFb)
            .putString(KEY_TIKTOK, cleanTiktok)
            .putString(KEY_YOUTUBE, cleanYoutube)
            .apply()

        currentLinks.value = SocialLinks(
            facebookUrl = cleanFb,
            tiktokUrl = cleanTiktok,
            youtubeUrl = cleanYoutube
        )
    }
}
