package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.example.data.db.PhoneEntity
import com.example.data.model.ModelTutorialVideo
import com.example.data.model.ModelVideoManager

@Composable
fun ModelVideoDialog(
    phone: PhoneEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var showEditModal by remember { mutableStateOf(false) }

    // Re-evaluate video whenever map changes or edit is made
    val modelVideo = ModelVideoManager.getVideoForPhone(phone)

    val cleanUrlOrId = modelVideo.videoUrlOrId.trim()
    val isTikTok = cleanUrlOrId.contains("tiktok.com") || modelVideo.platform.equals("TikTok", ignoreCase = true)
    val youtubeId = extractYoutubeIdFromInput(cleanUrlOrId)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFFF3D00).copy(alpha = 0.15f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🎥", fontSize = 20.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "فيديو تجديد ${phone.brand} ${phone.modelName}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "فيديو تعليمي حقيقي خاص بـ ${phone.modelName}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = { showEditModal = true },
                            modifier = Modifier.testTag("btn_edit_model_video_icon")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "تعديل الفيديو",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Video Player Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (isTikTok) {
                        // TikTok Preview Container
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text("🎵 فيديو TikTok تعليمي خاص بالشاشة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val fullLink = if (cleanUrlOrId.startsWith("http")) cleanUrlOrId else "https://www.tiktok.com/@$cleanUrlOrId"
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullLink))
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFE2C55)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح وتشغيل الفيديو على TikTok 🎵", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else if (youtubeId.isNotBlank()) {
                        // YouTube Embedded Player
                        ModelYouTubeWebPlayer(videoId = youtubeId)
                    } else {
                        // Web or External Link
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text("🎥 فيديو تعليمي خارجي", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(cleanUrlOrId))
                                    context.startActivity(intent)
                                }
                            ) {
                                Text("فتح الفيديو في المتصفح")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Bar: Open External & Share & Edit
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val targetUri = when {
                                isTikTok -> if (cleanUrlOrId.startsWith("http")) cleanUrlOrId else "https://www.tiktok.com"
                                youtubeId.isNotBlank() -> "https://www.youtube.com/watch?v=$youtubeId"
                                else -> cleanUrlOrId
                            }
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUri))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isTikTok) "فتح في تيكتوك" else "فتح في يوتيوب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { showEditModal = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_edit_model_video_dialog"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تعديل الفيديو ✏️", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Model Tech Specs Quick Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = modelVideo.customTitle.ifBlank { "تجديد شاشة ${phone.modelName}" },
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )

                        if (modelVideo.customNotes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = modelVideo.customNotes,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 12.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Thermostat, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "الحرارة: ${modelVideo.tempCelsius}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "السلك: ${modelVideo.wireThickness}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditModal) {
        EditModelVideoModal(
            phone = phone,
            currentVideo = modelVideo,
            onDismiss = { showEditModal = false }
        )
    }
}

@Composable
fun EditModelVideoModal(
    phone: PhoneEntity,
    currentVideo: ModelTutorialVideo,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var videoUrlInput by remember { mutableStateOf(currentVideo.videoUrlOrId) }
    var customTitle by remember { mutableStateOf(currentVideo.customTitle) }
    var customNotes by remember { mutableStateOf(currentVideo.customNotes) }
    var tempCelsius by remember { mutableStateOf(currentVideo.tempCelsius) }
    var wireThickness by remember { mutableStateOf(currentVideo.wireThickness) }
    var platform by remember { mutableStateOf(currentVideo.platform) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تعديل فيديو موديل ${phone.modelName} 🎬",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "ضع رابط الفيديو الخاص بموديل ${phone.brand} ${phone.modelName} (YouTube أو TikTok):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Video URL / ID Input
                OutlinedTextField(
                    value = videoUrlInput,
                    onValueChange = { input ->
                        videoUrlInput = input
                        if (input.contains("tiktok.com")) {
                            platform = "TikTok"
                        } else if (input.contains("youtu")) {
                            platform = "YouTube"
                        }
                    },
                    label = { Text("رابط يوتيوب أو تيكتوك (أو Video ID)") },
                    placeholder = { Text("https://www.youtube.com/watch?v=... أو TikTok") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_model_video_url"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Title
                OutlinedTextField(
                    value = customTitle,
                    onValueChange = { customTitle = it },
                    label = { Text("عنوان الشرح / الفيديو") },
                    placeholder = { Text("مثال: تغيير زجاج باغة Samsung A02 خطوة بخطوة") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Notes
                OutlinedTextField(
                    value = customNotes,
                    onValueChange = { customNotes = it },
                    label = { Text("ملاحظات فنية خاصة بتجديد هذا الموديل") },
                    placeholder = { Text("مثل درجة الحرارة المناسبة أو أخطاء يجب تجنبها") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = tempCelsius,
                        onValueChange = { tempCelsius = it },
                        label = { Text("درجة الحرارة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = wireThickness,
                        onValueChange = { wireThickness = it },
                        label = { Text("سمك السلك") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Save Button
                Button(
                    onClick = {
                        if (videoUrlInput.isBlank()) {
                            Toast.makeText(context, "الرجاء إدخال رابط أو معرّف الفيديو", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val updatedVideo = ModelTutorialVideo(
                            modelKey = ModelVideoManager.getNormalizedKey(phone.brand, phone.modelName, phone.modelCode),
                            modelNameDisplay = "${phone.brand} ${phone.modelName}",
                            videoUrlOrId = videoUrlInput.trim(),
                            platform = platform,
                            customTitle = customTitle.ifBlank { "تجديد شاشة ${phone.brand} ${phone.modelName}" },
                            customNotes = customNotes,
                            tempCelsius = tempCelsius.ifBlank { "${phone.separationTempCelsius}°C" },
                            wireThickness = wireThickness.ifBlank { phone.wireSizeMm }
                        )

                        ModelVideoManager.saveVideoForPhone(context, phone, updatedVideo)
                        Toast.makeText(context, "تم حفظ الفيديو الخاص بموديل ${phone.modelName} 🎬", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_save_model_video"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("حفظ رابط الفيديو الموديل 💾", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ModelYouTubeWebPlayer(
    videoId: String,
    modifier: Modifier = Modifier
) {
    val htmlContent = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body { margin: 0; padding: 0; background-color: #000000; display: flex; justify-content: center; align-items: center; height: 100vh; }
                iframe { width: 100%; height: 100%; border: none; }
            </style>
        </head>
        <body>
            <iframe src="https://www.youtube.com/embed/$videoId?autoplay=1&modestbranding=1&rel=0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </body>
        </html>
    """.trimIndent()

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = WebViewClient()
                loadDataWithBaseURL("https://www.youtube.com", htmlContent, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL("https://www.youtube.com", htmlContent, "text/html", "UTF-8", null)
        },
        modifier = modifier
    )
}

private fun extractYoutubeIdFromInput(input: String): String {
    val trimmed = input.trim()
    if (trimmed.length == 11 && !trimmed.contains("/") && !trimmed.contains(".")) {
        return trimmed
    }
    return when {
        trimmed.contains("youtu.be/") -> trimmed.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
        trimmed.contains("v=") -> trimmed.substringAfter("v=").substringBefore("&")
        trimmed.contains("embed/") -> trimmed.substringAfter("embed/").substringBefore("?").substringBefore("&")
        else -> if (!trimmed.contains("tiktok.com")) trimmed else ""
    }
}
