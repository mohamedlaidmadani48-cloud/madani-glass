package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanVariant = Color(0xFF00B0FF)
val PhosphorEmerald = Color(0xFF00E676)
val WorkshopDarkBackground = Color(0xFF090D16)
val WorkshopDarkSurface = Color(0xFF111827)
val WorkshopDarkCard = Color(0xFF1E293B)
val WorkshopDarkCardBorder = Color(0xFF334155)

val HighContrastText = Color(0xFFF8FAFC)
val SubtitleText = Color(0xFF94A3B8)
val AccentAmber = Color(0xFFFFC107)
val DangerRed = Color(0xFFFF5252)
