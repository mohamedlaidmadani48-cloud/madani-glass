package com.example.data.repository

import com.example.data.db.InitialSeedData
import com.example.data.db.PhoneDao
import com.example.data.db.PhoneEntity
import kotlinx.coroutines.flow.Flow

class PhoneRepository(private val phoneDao: PhoneDao) {

    val allPhones: Flow<List<PhoneEntity>> = phoneDao.getAllPhones()
    val favoritePhones: Flow<List<PhoneEntity>> = phoneDao.getFavoritePhones()

    fun searchPhones(query: String): Flow<List<PhoneEntity>> {
        return if (query.isBlank()) {
            phoneDao.getAllPhones()
        } else {
            phoneDao.searchPhones(query.trim())
        }
    }

    fun getPhonesByGroupId(groupId: String): Flow<List<PhoneEntity>> {
        return phoneDao.getPhonesByGroupId(groupId)
    }

    suspend fun getPhoneById(id: Int): PhoneEntity? {
        return phoneDao.getPhoneById(id)
    }

    suspend fun insertPhone(phone: PhoneEntity): Long {
        return phoneDao.insertPhone(phone)
    }

    suspend fun updatePhone(phone: PhoneEntity) {
        phoneDao.updatePhone(phone)
    }

    suspend fun deletePhone(phone: PhoneEntity) {
        phoneDao.deletePhone(phone)
    }

    suspend fun toggleFavorite(id: Int, isFavorite: Boolean) {
        phoneDao.setFavorite(id, isFavorite)
    }

    suspend fun updateUserNotes(id: Int, notes: String) {
        phoneDao.updateUserNotes(id, notes)
    }

    suspend fun ensureDatabaseSeeded() {
        if (phoneDao.getPhoneCount() == 0) {
            phoneDao.insertPhones(InitialSeedData.seedPhones)
        }
    }
}
