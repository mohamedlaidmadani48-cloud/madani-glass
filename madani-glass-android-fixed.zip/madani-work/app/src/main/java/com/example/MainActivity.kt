package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MainViewModel
import com.example.ui.theme.MadaniGlassTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.SocialLinksManager.init(applicationContext)
        com.example.data.AppSettingsManager.init(applicationContext)
        com.example.data.SubscriberManager.init(applicationContext)
        com.example.data.model.EquipmentCatalogData.init(applicationContext)
        com.example.data.model.RefurbishTutorialsData.init(applicationContext)
        com.example.data.model.ModelVideoManager.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            MadaniGlassTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    HomeScreen(viewModel = viewModel)
                }
            }
        }
    }
}
