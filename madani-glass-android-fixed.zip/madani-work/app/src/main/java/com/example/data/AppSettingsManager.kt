package com.example.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

data class AppCustomSettings(
    val appTitle: String = "مدني جلاس | MADANI GLASS",
    val appSubtitle: String = "دليل التوافقات والتجديد لفنيي الصيانة",
    val phoneNumber: String = "0550000000",
    val storeAddress: String = "الجزائر - توصيل 58 ولاية",
    val announcementText: String = "توصيل سريع لقطع غيار ومعدات تجديد الشاشات لجميع الولايات 🇩🇿",
    val isSubscriptionModeEnabled: Boolean = false,
    val monthlySubPriceDzd: String = "1,500 د.ج / شهر ($10)",
    val yearlySubPriceDzd: String = "12,000 د.ج / سنة ($80)",
    val baridiMobRip: String = "00799999000123456789",
    val visaCardDetails: String = "4532 XXXX XXXX 8901 (Visa / Mastercard)",
    val usdtWalletAddress: String = "TYu89Xz45K90PqLmRtS23VwZ78NmLkPqTRC20",
    val activeSubscriptionPlan: String = "None"
)

object AppSettingsManager {
    private const val PREFS_NAME = "madani_app_customization_prefs"
    private const val KEY_TITLE = "app_title"
    private const val KEY_SUBTITLE = "app_subtitle"
    private const val KEY_PHONE = "phone_number"
    private const val KEY_ADDRESS = "store_address"
    private const val KEY_ANNOUNCEMENT = "announcement_text"
    private const val KEY_SUB_ENABLED = "is_subscription_enabled"
    private const val KEY_MONTHLY_PRICE = "monthly_sub_price"
    private const val KEY_YEARLY_PRICE = "yearly_sub_price"
    private const val KEY_BARIDIMOB = "baridimob_rip"
    private const val KEY_VISA = "visa_details"
    private const val KEY_USDT = "usdt_address"
    private const val KEY_ACTIVE_PLAN = "active_subscription_plan"

    val currentSettings = mutableStateOf(AppCustomSettings())

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val title = prefs.getString(KEY_TITLE, "مدني جلاس | MADANI GLASS") ?: "مدني جلاس | MADANI GLASS"
        val subtitle = prefs.getString(KEY_SUBTITLE, "دليل التوافقات والتجديد لفنيي الصيانة") ?: "دليل التوافقات والتجديد لفنيي الصيانة"
        val phone = prefs.getString(KEY_PHONE, "0550000000") ?: "0550000000"
        val address = prefs.getString(KEY_ADDRESS, "الجزائر - توصيل 58 ولاية") ?: "الجزائر - توصيل 58 ولاية"
        val announcement = prefs.getString(KEY_ANNOUNCEMENT, "توصيل سريع لقطع غيار ومعدات تجديد الشاشات لجميع الولايات 🇩🇿") ?: "توصيل سريع لقطع غيار ومعدات تجديد الشاشات لجميع الولايات 🇩🇿"
        
        val subEnabled = prefs.getBoolean(KEY_SUB_ENABLED, false)
        val monthlyPrice = prefs.getString(KEY_MONTHLY_PRICE, "1,500 د.ج / شهر ($10)") ?: "1,500 د.ج / شهر ($10)"
        val yearlyPrice = prefs.getString(KEY_YEARLY_PRICE, "12,000 د.ج / سنة ($80)") ?: "12,000 د.ج / سنة ($80)"
        val baridiMob = prefs.getString(KEY_BARIDIMOB, "00799999000123456789") ?: "00799999000123456789"
        val visa = prefs.getString(KEY_VISA, "4532 XXXX XXXX 8901 (Visa / Mastercard)") ?: "4532 XXXX XXXX 8901 (Visa / Mastercard)"
        val usdt = prefs.getString(KEY_USDT, "TYu89Xz45K90PqLmRtS23VwZ78NmLkPqTRC20") ?: "TYu89Xz45K90PqLmRtS23VwZ78NmLkPqTRC20"
        val activePlan = prefs.getString(KEY_ACTIVE_PLAN, "None") ?: "None"

        currentSettings.value = AppCustomSettings(
            appTitle = title,
            appSubtitle = subtitle,
            phoneNumber = phone,
            storeAddress = address,
            announcementText = announcement,
            isSubscriptionModeEnabled = subEnabled,
            monthlySubPriceDzd = monthlyPrice,
            yearlySubPriceDzd = yearlyPrice,
            baridiMobRip = baridiMob,
            visaCardDetails = visa,
            usdtWalletAddress = usdt,
            activeSubscriptionPlan = activePlan
        )
    }

    fun saveSettings(
        context: Context,
        title: String,
        subtitle: String,
        phone: String,
        address: String,
        announcement: String,
        isSubscriptionEnabled: Boolean,
        monthlyPrice: String,
        yearlyPrice: String,
        baridiMob: String,
        visa: String,
        usdt: String
    ) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cleanTitle = if (title.isBlank()) "مدني جلاس | MADANI GLASS" else title.trim()
        val cleanSubtitle = if (subtitle.isBlank()) "دليل التوافقات والتجديد لفنيي الصيانة" else subtitle.trim()
        val cleanPhone = if (phone.isBlank()) "0550000000" else phone.trim()
        val cleanAddress = if (address.isBlank()) "الجزائر - توصيل 58 ولاية" else address.trim()
        val cleanAnnouncement = if (announcement.isBlank()) "توصيل سريع لقطع غيار ومعدات تجديد الشاشات لجميع الولايات 🇩🇿" else announcement.trim()
        
        val cleanMonthly = if (monthlyPrice.isBlank()) "1,500 د.ج / شهر ($10)" else monthlyPrice.trim()
        val cleanYearly = if (yearlyPrice.isBlank()) "12,000 د.ج / سنة ($80)" else yearlyPrice.trim()
        val cleanBaridiMob = if (baridiMob.isBlank()) "00799999000123456789" else baridiMob.trim()
        val cleanVisa = if (visa.isBlank()) "4532 XXXX XXXX 8901 (Visa / Mastercard)" else visa.trim()
        val cleanUsdt = if (usdt.isBlank()) "TYu89Xz45K90PqLmRtS23VwZ78NmLkPqTRC20" else usdt.trim()

        prefs.edit()
            .putString(KEY_TITLE, cleanTitle)
            .putString(KEY_SUBTITLE, cleanSubtitle)
            .putString(KEY_PHONE, cleanPhone)
            .putString(KEY_ADDRESS, cleanAddress)
            .putString(KEY_ANNOUNCEMENT, cleanAnnouncement)
            .putBoolean(KEY_SUB_ENABLED, isSubscriptionEnabled)
            .putString(KEY_MONTHLY_PRICE, cleanMonthly)
            .putString(KEY_YEARLY_PRICE, cleanYearly)
            .putString(KEY_BARIDIMOB, cleanBaridiMob)
            .putString(KEY_VISA, cleanVisa)
            .putString(KEY_USDT, cleanUsdt)
            .apply()

        currentSettings.value = currentSettings.value.copy(
            appTitle = cleanTitle,
            appSubtitle = cleanSubtitle,
            phoneNumber = cleanPhone,
            storeAddress = cleanAddress,
            announcementText = cleanAnnouncement,
            isSubscriptionModeEnabled = isSubscriptionEnabled,
            monthlySubPriceDzd = cleanMonthly,
            yearlySubPriceDzd = cleanYearly,
            baridiMobRip = cleanBaridiMob,
            visaCardDetails = cleanVisa,
            usdtWalletAddress = cleanUsdt
        )
    }

    fun setActiveSubscriptionPlan(context: Context, plan: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ACTIVE_PLAN, plan).apply()
        currentSettings.value = currentSettings.value.copy(activeSubscriptionPlan = plan)
    }
}

