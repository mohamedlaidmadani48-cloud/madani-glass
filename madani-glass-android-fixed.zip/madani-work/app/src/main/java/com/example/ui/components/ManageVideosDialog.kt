package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.RefurbishStageVideo
import com.example.data.model.RefurbishTutorialsData
import java.util.UUID

@Composable
fun ManageVideosDialog(
    initialVideoToEdit: RefurbishStageVideo? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val videoList = RefurbishTutorialsData.stagesList

    var videoToEdit by remember { mutableStateOf<RefurbishStageVideo?>(initialVideoToEdit) }
    var showAddDialog by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إدارة الفيديوهات التعليمية 🎬",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { showAddDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_add_new_video_modal"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة فيديو جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            RefurbishTutorialsData.resetToDefaults(context)
                            Toast.makeText(context, "تمت إعادة الفيديوهات الافتراضية 🔄", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إعادة الافتراضي", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "الفيديوهات الحالية (${videoList.size}):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Video List
                videoList.forEachIndexed { index, video ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.titleAr,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 2
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "معرّف يوتيوب: ${video.youtubeVideoId} | المدة: ${video.duration}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 11.sp
                                    )
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { videoToEdit = video },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        RefurbishTutorialsData.deleteVideo(context, video.id)
                                        Toast.makeText(context, "تم حذف الفيديو", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color.Red,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog || videoToEdit != null) {
        AddEditVideoModal(
            existingVideo = videoToEdit,
            onDismiss = {
                showAddDialog = false
                videoToEdit = null
            }
        )
    }
}

@Composable
fun AddEditVideoModal(
    existingVideo: RefurbishStageVideo?,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    var titleAr by remember { mutableStateOf(existingVideo?.titleAr ?: "") }
    var youtubeId by remember { mutableStateOf(existingVideo?.youtubeVideoId ?: "") }
    var duration by remember { mutableStateOf(existingVideo?.duration ?: "05:00") }
    var stageNumberText by remember { mutableStateOf(existingVideo?.stageNumber?.toString() ?: "1") }
    var targetScreenType by remember { mutableStateOf(existingVideo?.targetScreenType ?: "All") }
    var descriptionAr by remember { mutableStateOf(existingVideo?.descriptionAr ?: "") }
    var toolsNeededAr by remember { mutableStateOf(existingVideo?.toolsNeededAr ?: "") }
    var recommendedTemp by remember { mutableStateOf(existingVideo?.recommendedTemp ?: "85°C") }
    var wireThickness by remember { mutableStateOf(existingVideo?.wireThickness ?: "0.028 mm") }
    var tipsArText by remember { mutableStateOf(existingVideo?.tipsAr?.joinToString("\n") ?: "") }

    val presetScreenTypes = listOf(
        "All" to "🌐 عام (الكل)",
        "iPhone" to "📱 آيفون",
        "Edge" to "🌀 Edge منحنية",
        "Super AMOLED" to "💎 Super AMOLED",
        "AMOLED" to "✨ AMOLED / OLED",
        "LCD" to "💡 LCD"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (existingVideo != null) "تعديل الفيديو التعليمي ✏️" else "إضافة فيديو تعليمي جديد 🎬",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Title
                OutlinedTextField(
                    value = titleAr,
                    onValueChange = { titleAr = it },
                    label = { Text("عنوان الفيديو (بالعربية)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_video_title_ar"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Target Screen Type Selection
                Text(
                    text = "نوع الشاشات / الموديلات المتوافقة:",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(presetScreenTypes) { (typeKey, typeLabel) ->
                        val isSelected = targetScreenType == typeKey
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { targetScreenType = typeKey },
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            )
                        ) {
                            Text(
                                text = typeLabel,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = targetScreenType,
                    onValueChange = { targetScreenType = it },
                    label = { Text("أو اكتب موديل خاص (مثال: iPhone 13 Pro, Galaxy S21)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_target_screen_type"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // YouTube Video ID / Link
                    OutlinedTextField(
                        value = youtubeId,
                        onValueChange = { youtubeId = extractYoutubeId(it) },
                        label = { Text("معرّف أو رابط يوتيوب (Video ID)") },
                        modifier = Modifier.weight(1f).testTag("input_youtube_id"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Duration
                    OutlinedTextField(
                        value = duration,
                        onValueChange = { duration = it },
                        label = { Text("المدة (مثلاً 05:30)") },
                        modifier = Modifier.weight(0.7f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Recommended Temp
                    OutlinedTextField(
                        value = recommendedTemp,
                        onValueChange = { recommendedTemp = it },
                        label = { Text("الحرارة الموصى بها") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Wire Thickness
                    OutlinedTextField(
                        value = wireThickness,
                        onValueChange = { wireThickness = it },
                        label = { Text("سمك سلك القطع") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tools Needed
                OutlinedTextField(
                    value = toolsNeededAr,
                    onValueChange = { toolsNeededAr = it },
                    label = { Text("الأدوات المطلوبة") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Description
                OutlinedTextField(
                    value = descriptionAr,
                    onValueChange = { descriptionAr = it },
                    label = { Text("شرح الشرح والتطبيق العملي") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Tips (one per line)
                OutlinedTextField(
                    value = tipsArText,
                    onValueChange = { tipsArText = it },
                    label = { Text("نصائح وإرشادات هامة (كل نصيحة في سطر جديد)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Save Button
                Button(
                    onClick = {
                        if (titleAr.isBlank() || youtubeId.isBlank()) {
                            Toast.makeText(context, "الرجاء إدخال عنوان الفيديو ورابط أو معرّف يوتيوب", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        val tipsList = tipsArText.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                        val stageNum = stageNumberText.trim().toIntOrNull() ?: 1

                        val video = RefurbishStageVideo(
                            id = existingVideo?.id ?: "custom_vid_${UUID.randomUUID().toString().take(8)}",
                            stageNumber = stageNum,
                            titleAr = titleAr.trim(),
                            titleEn = existingVideo?.titleEn ?: titleAr.trim(),
                            titleFr = existingVideo?.titleFr ?: titleAr.trim(),
                            duration = duration.ifBlank { "05:00" },
                            youtubeVideoId = youtubeId.trim(),
                            descriptionAr = descriptionAr.ifBlank { titleAr.trim() },
                            descriptionEn = existingVideo?.descriptionEn ?: titleAr.trim(),
                            descriptionFr = existingVideo?.descriptionFr ?: titleAr.trim(),
                            tipsAr = tipsList.ifEmpty { listOf("اتبّع الخطوات بدقة لضمان نجاح التجديد") },
                            tipsEn = existingVideo?.tipsEn ?: listOf("Follow the steps carefully"),
                            tipsFr = existingVideo?.tipsFr ?: listOf("Suivez les étapes avec soin"),
                            toolsNeededAr = toolsNeededAr.ifBlank { "سخان شاشات، سلك قطع" },
                            toolsNeededEn = existingVideo?.toolsNeededEn ?: "Separator, Wire",
                            toolsNeededFr = existingVideo?.toolsNeededFr ?: "Séparateur, Fil",
                            recommendedTemp = recommendedTemp.ifBlank { "85°C" },
                            wireThickness = wireThickness.ifBlank { "0.028 mm" },
                            targetScreenType = targetScreenType.ifBlank { "All" }
                        )

                        if (existingVideo != null) {
                            RefurbishTutorialsData.updateVideo(context, video)
                            Toast.makeText(context, "تم حفظ تعديلات الفيديو 🎬", Toast.LENGTH_SHORT).show()
                        } else {
                            RefurbishTutorialsData.addVideo(context, video)
                            Toast.makeText(context, "تمت إضافة الفيديو بنجاح 🎬", Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// Helper function to extract YouTube video ID from various link formats
private fun extractYoutubeId(input: String): String {
    val trimmed = input.trim()
    if (trimmed.length == 11 && !trimmed.contains("/") && !trimmed.contains(".")) {
        return trimmed
    }
    return when {
        trimmed.contains("youtu.be/") -> trimmed.substringAfter("youtu.be/").substringBefore("?").substringBefore("&")
        trimmed.contains("v=") -> trimmed.substringAfter("v=").substringBefore("&")
        trimmed.contains("embed/") -> trimmed.substringAfter("embed/").substringBefore("?").substringBefore("&")
        else -> trimmed
    }
}
