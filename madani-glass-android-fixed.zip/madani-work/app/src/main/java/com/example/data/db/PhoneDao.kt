package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PhoneDao {

    @Query("SELECT * FROM phones ORDER BY brand ASC, modelName ASC")
    fun getAllPhones(): Flow<List<PhoneEntity>>

    @Query("SELECT * FROM phones WHERE isFavorite = 1 ORDER BY brand ASC, modelName ASC")
    fun getFavoritePhones(): Flow<List<PhoneEntity>>

    @Query("""
        SELECT * FROM phones 
        WHERE LOWER(modelName) LIKE '%' || LOWER(:query) || '%' 
           OR LOWER(modelCode) LIKE '%' || LOWER(:query) || '%'
           OR LOWER(brand) LIKE '%' || LOWER(:query) || '%'
           OR LOWER(compatibleModels) LIKE '%' || LOWER(:query) || '%'
        ORDER BY brand ASC, modelName ASC
    """)
    fun searchPhones(query: String): Flow<List<PhoneEntity>>

    @Query("SELECT * FROM phones WHERE compatibilityGroupId = :groupId")
    fun getPhonesByGroupId(groupId: String): Flow<List<PhoneEntity>>

    @Query("SELECT * FROM phones WHERE id = :id LIMIT 1")
    suspend fun getPhoneById(id: Int): PhoneEntity?

    @Query("SELECT COUNT(*) FROM phones")
    suspend fun getPhoneCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhone(phone: PhoneEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhones(phones: List<PhoneEntity>)

    @Update
    suspend fun updatePhone(phone: PhoneEntity)

    @Delete
    suspend fun deletePhone(phone: PhoneEntity)

    @Query("UPDATE phones SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Int, isFavorite: Boolean)

    @Query("UPDATE phones SET userNotes = :notes WHERE id = :id")
    suspend fun updateUserNotes(id: Int, notes: String)
}
