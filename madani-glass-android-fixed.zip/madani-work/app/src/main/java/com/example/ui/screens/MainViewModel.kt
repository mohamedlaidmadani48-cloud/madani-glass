package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.PhoneEntity
import com.example.data.repository.PhoneRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PhoneRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedBrand = MutableStateFlow("All")
    val selectedBrand: StateFlow<String> = _selectedBrand.asStateFlow()

    private val _showOnlyFavorites = MutableStateFlow(false)
    val showOnlyFavorites: StateFlow<Boolean> = _showOnlyFavorites.asStateFlow()

    private val _selectedPhoneForDetail = MutableStateFlow<PhoneEntity?>(null)
    val selectedPhoneForDetail: StateFlow<PhoneEntity?> = _selectedPhoneForDetail.asStateFlow()

    private val _selectedPhoneForNotes = MutableStateFlow<PhoneEntity?>(null)
    val selectedPhoneForNotes: StateFlow<PhoneEntity?> = _selectedPhoneForNotes.asStateFlow()

    private val _selectedPhoneForEdit = MutableStateFlow<PhoneEntity?>(null)
    val selectedPhoneForEdit: StateFlow<PhoneEntity?> = _selectedPhoneForEdit.asStateFlow()

    private val _showAddPhoneDialog = MutableStateFlow(false)
    val showAddPhoneDialog: StateFlow<Boolean> = _showAddPhoneDialog.asStateFlow()

    private val _showToolsDialog = MutableStateFlow(false)
    val showToolsDialog: StateFlow<Boolean> = _showToolsDialog.asStateFlow()

    private val _showVideoTutorialsDialog = MutableStateFlow(false)
    val showVideoTutorialsDialog: StateFlow<Boolean> = _showVideoTutorialsDialog.asStateFlow()

    private val _videoTutorialStageIndex = MutableStateFlow(0)
    val videoTutorialStageIndex: StateFlow<Int> = _videoTutorialStageIndex.asStateFlow()

    init {
        val phoneDao = AppDatabase.getDatabase(application).phoneDao()
        repository = PhoneRepository(phoneDao)
        viewModelScope.launch {
            repository.ensureDatabaseSeeded()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val phonesList: StateFlow<List<PhoneEntity>> = combine(
        _searchQuery,
        _selectedBrand,
        _showOnlyFavorites
    ) { query, brand, favoritesOnly ->
        Triple(query, brand, favoritesOnly)
    }.flatMapLatest { (query, brand, favoritesOnly) ->
        val flow = if (favoritesOnly) {
            repository.favoritePhones
        } else {
            repository.searchPhones(query)
        }
        flow
    }.combine(_selectedBrand) { list, brand ->
        if (brand == "All" || brand.isBlank()) {
            list
        } else {
            list.filter { it.brand.equals(brand, ignoreCase = true) }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onBrandSelected(brand: String) {
        _selectedBrand.value = brand
        if (brand == "Favorites") {
            _showOnlyFavorites.value = true
        } else {
            _showOnlyFavorites.value = false
        }
    }

    fun toggleFavoritesFilter() {
        _showOnlyFavorites.value = !_showOnlyFavorites.value
    }

    fun toggleFavorite(phone: PhoneEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(phone.id, !phone.isFavorite)
        }
    }

    fun openDetail(phone: PhoneEntity) {
        _selectedPhoneForDetail.value = phone
    }

    fun closeDetail() {
        _selectedPhoneForDetail.value = null
    }

    fun openNotesEditor(phone: PhoneEntity) {
        _selectedPhoneForNotes.value = phone
    }

    fun closeNotesEditor() {
        _selectedPhoneForNotes.value = null
    }

    fun saveUserNotes(notes: String) {
        val phone = _selectedPhoneForNotes.value ?: return
        viewModelScope.launch {
            repository.updateUserNotes(phone.id, notes)
            _selectedPhoneForNotes.value = null
        }
    }

    fun showAddPhoneDialog() {
        _showAddPhoneDialog.value = true
    }

    fun hideAddPhoneDialog() {
        _showAddPhoneDialog.value = false
    }

    fun showToolsDialog() {
        _showToolsDialog.value = true
    }

    fun hideToolsDialog() {
        _showToolsDialog.value = false
    }

    fun addNewPhone(phone: PhoneEntity) {
        viewModelScope.launch {
            repository.insertPhone(phone)
            _showAddPhoneDialog.value = false
        }
    }

    fun openPhoneEditor(phone: PhoneEntity) {
        _selectedPhoneForEdit.value = phone
    }

    fun closePhoneEditor() {
        _selectedPhoneForEdit.value = null
    }

    fun updatePhone(phone: PhoneEntity) {
        viewModelScope.launch {
            repository.updatePhone(phone)
            _selectedPhoneForEdit.value = null
            // Update detail sheet if it's currently showing this phone
            if (_selectedPhoneForDetail.value?.id == phone.id) {
                _selectedPhoneForDetail.value = phone
            }
        }
    }

    fun deletePhone(phone: PhoneEntity) {
        viewModelScope.launch {
            repository.deletePhone(phone)
            _selectedPhoneForEdit.value = null
            if (_selectedPhoneForDetail.value?.id == phone.id) {
                _selectedPhoneForDetail.value = null
            }
        }
    }

    fun showVideoTutorials(stageIndex: Int = 0) {
        _videoTutorialStageIndex.value = stageIndex
        _showVideoTutorialsDialog.value = true
    }

    fun hideVideoTutorials() {
        _showVideoTutorialsDialog.value = false
    }
}
