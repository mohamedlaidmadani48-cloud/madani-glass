package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.derivedStateOf
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.Settings
import com.example.R
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppSettingsManager
import com.example.data.SubscriberManager
import com.example.data.db.PhoneEntity
import com.example.ui.components.AddPhoneDialog
import com.example.ui.components.DetailSheet
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.PhoneAndroid
import com.example.ui.components.EditAppSettingsDialog
import com.example.ui.components.PhoneAuthDialog
import com.example.ui.components.EditPhoneDialog
import com.example.ui.components.QrScannerDialog
import com.example.ui.components.EquipmentStoreView
import com.example.ui.components.HeaderSocialQuickIcons
import com.example.ui.components.PhoneCard
import com.example.ui.components.RefurbishToolsDialog
import com.example.ui.components.SocialMediaCardSection
import com.example.ui.components.TechnicianNoteDialog
import com.example.ui.components.VideoTutorialsDialog
import com.example.ui.language.AppLanguage
import com.example.ui.language.LanguageState
import com.example.ui.language.Strings

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedBrand by viewModel.selectedBrand.collectAsStateWithLifecycle()
    val phonesList by viewModel.phonesList.collectAsStateWithLifecycle()
    val selectedPhoneDetail by viewModel.selectedPhoneForDetail.collectAsStateWithLifecycle()
    val selectedPhoneNotes by viewModel.selectedPhoneForNotes.collectAsStateWithLifecycle()
    val selectedPhoneEdit by viewModel.selectedPhoneForEdit.collectAsStateWithLifecycle()
    val showAddDialog by viewModel.showAddPhoneDialog.collectAsStateWithLifecycle()
    val showToolsDialog by viewModel.showToolsDialog.collectAsStateWithLifecycle()
    val showVideoTutorialsDialog by viewModel.showVideoTutorialsDialog.collectAsStateWithLifecycle()
    val videoTutorialStageIndex by viewModel.videoTutorialStageIndex.collectAsStateWithLifecycle()

    val currentLang = LanguageState.currentLanguage.value
    var langMenuExpanded by remember { mutableStateOf(false) }
    var selectedScreenTab by remember { mutableStateOf(0) }
    var showAppSettingsDialog by remember { mutableStateOf(false) }
    var showQrScannerDialog by remember { mutableStateOf(false) }
    var showPhoneAuthDialog by remember { mutableStateOf(false) }
    var lockedPhoneTeaser by remember { mutableStateOf<PhoneEntity?>(null) }
    val appCustom = AppSettingsManager.currentSettings.value
    val currentUser = SubscriberManager.currentUserState.value
    val isSubMode = appCustom.isSubscriptionModeEnabled

    val listState = rememberLazyListState()
    val isListScrolled by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 30
        }
    }

    val brandFilters = listOf(
        "All",
        "Samsung",
        "Apple",
        "Xiaomi",
        "Oppo",
        "Vivo",
        "Realme",
        "Infinix",
        "Favorites"
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedScreenTab == 0,
                    onClick = { selectedScreenTab = 0 },
                    icon = { Icon(Icons.Default.Smartphone, contentDescription = null) },
                    label = { Text(Strings.get("nav_compatibility"), fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_tab_compatibility")
                )

                NavigationBarItem(
                    selected = selectedScreenTab == 1,
                    onClick = { selectedScreenTab = 1 },
                    icon = { Icon(Icons.Default.Storefront, contentDescription = null) },
                    label = { Text(Strings.get("nav_store"), fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("nav_tab_store")
                )
            }
        },
        floatingActionButton = {
            if (selectedScreenTab == 0) {
                FloatingActionButton(
                    onClick = { viewModel.showAddPhoneDialog() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape,
                    modifier = Modifier.testTag("add_phone_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Phone")
                }
            }
        }
    ) { innerPadding ->
        if (selectedScreenTab == 1) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                EquipmentStoreView()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp)
            ) {
            Spacer(modifier = Modifier.height(12.dp))

            // App Bar Header: Title, Subtitle & Language Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo_icon_1784973324505),
                        contentDescription = "App Logo",
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = appCustom.appTitle,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 19.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = appCustom.appSubtitle,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Customization, Phone Auth & Language Switcher
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {

                    // Phone Auth / Subscriber Profile Button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                1.dp,
                                if (currentUser?.isActive == true) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { showPhoneAuthDialog = true }
                            .testTag("open_phone_auth_btn"),
                        color = if (currentUser?.isActive == true) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = "Phone Login",
                                tint = if (currentUser?.isActive == true) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (currentUser != null) currentUser.fullName.take(8) else "دخول 📲",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (currentUser?.isActive == true) Color(0xFF1B5E20) else MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }

                    // Edit App Info Settings Button
                    Surface(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .clickable { showAppSettingsDialog = true }
                            .testTag("open_app_customization_btn"),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Edit App Info",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Box {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                                .clickable { langMenuExpanded = true }
                                .testTag("language_toggle_button"),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = currentLang.flag, fontSize = 15.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentLang.displayName,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = langMenuExpanded,
                            onDismissRequest = { langMenuExpanded = false },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
                        ) {
                            AppLanguage.values().forEach { lang ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(lang.flag)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(lang.displayName, fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    onClick = {
                                        LanguageState.setLanguage(lang)
                                        langMenuExpanded = false
                                    },
                                    modifier = Modifier.testTag("lang_item_${lang.code}")
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Tools: Refurbish Calculator & Video Tutorials Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Video Tutorials Hub Button
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.showVideoTutorials(0) }
                        .testTag("open_video_tutorials"),
                    color = Color(0xFFFF3D00).copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF3D00))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = null,
                            tint = Color(0xFFFF3D00),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = Strings.get("video_tutorials"),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF3D00)
                            )
                        )
                    }
                }

                // Heat & Wire Guide Button
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.showToolsDialog() }
                        .testTag("open_tools_guide"),
                    color = Color(0xFFFF7043).copy(alpha = 0.18f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF7043))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = null,
                            tint = Color(0xFFFF7043),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = Strings.get("refurbish_calculator"),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF7043)
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar & QR Scanner Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.onSearchQueryChanged(it) },
                    placeholder = {
                        Text(
                            text = Strings.get("search_placeholder"),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.onSearchQueryChanged("") },
                                modifier = Modifier.testTag("clear_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_text_input")
                )

                // QR Code Scanner Button
                Surface(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showQrScannerDialog = true }
                        .testTag("open_qr_scanner_btn"),
                    color = Color(0xFF00C853).copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF00C853))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Scan QR",
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = "QR",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF00E676)
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Social Media Channels Section (Right above Compatibilities)
            AnimatedVisibility(visible = searchQuery.isBlank() && !isListScrolled) {
                Column {
                    SocialMediaCardSection()
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Brand Filter Chips Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(brandFilters) { brand ->
                    val isSelected = selectedBrand == brand
                    val label = if (brand == "All") Strings.get("all") else if (brand == "Favorites") "⭐ " + Strings.get("favorites") else brand

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { viewModel.onBrandSelected(brand) }
                            .testTag("brand_chip_$brand"),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Text(
                            text = label,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Phone List or Empty State
            if (phonesList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text("🔍", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = Strings.get("no_results"),
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    itemsIndexed(
                        items = phonesList,
                        key = { _, item -> item.id }
                    ) { index, phone ->
                        val freeLimit = if (selectedBrand == "All") 12 else 3
                        val isLocked = (currentUser?.isActive != true) && (index >= freeLimit)
                        PhoneCard(
                            phone = phone,
                            isLocked = isLocked,
                            onCardClick = {
                                if (isLocked) {
                                    lockedPhoneTeaser = phone
                                } else {
                                    viewModel.openDetail(phone)
                                }
                            },
                            onFavoriteToggle = { viewModel.toggleFavorite(phone) },
                            onEditNotes = { viewModel.openNotesEditor(phone) },
                            onEditPhone = { viewModel.openPhoneEditor(phone) }
                        )
                    }
                }
            }
        }
    }
}

    // Modal Sheet & Dialogs Integration
    selectedPhoneDetail?.let { phone ->
        DetailSheet(
            phone = phone,
            onDismiss = { viewModel.closeDetail() },
            onEditNotes = {
                viewModel.closeDetail()
                viewModel.openNotesEditor(phone)
            },
            onEditPhone = {
                viewModel.openPhoneEditor(phone)
            },
            onOpenVideoTutorials = { stageIndex ->
                viewModel.showVideoTutorials(stageIndex)
            }
        )
    }

    selectedPhoneNotes?.let { phone ->
        TechnicianNoteDialog(
            phone = phone,
            onDismiss = { viewModel.closeNotesEditor() },
            onSaveNotes = { notes -> viewModel.saveUserNotes(notes) }
        )
    }

    selectedPhoneEdit?.let { phone ->
        EditPhoneDialog(
            phone = phone,
            onDismiss = { viewModel.closePhoneEditor() },
            onSavePhone = { updatedPhone -> viewModel.updatePhone(updatedPhone) },
            onDeletePhone = { phoneToDelete -> viewModel.deletePhone(phoneToDelete) }
        )
    }

    if (showAddDialog) {
        AddPhoneDialog(
            onDismiss = { viewModel.hideAddPhoneDialog() },
            onSavePhone = { newPhone -> viewModel.addNewPhone(newPhone) }
        )
    }

    if (showToolsDialog) {
        RefurbishToolsDialog(
            onDismiss = { viewModel.hideToolsDialog() }
        )
    }

    if (showVideoTutorialsDialog) {
        VideoTutorialsDialog(
            initialStageIndex = videoTutorialStageIndex,
            onDismiss = { viewModel.hideVideoTutorials() }
        )
    }

    if (showAppSettingsDialog) {
        EditAppSettingsDialog(
            onDismiss = { showAppSettingsDialog = false }
        )
    }

    if (showPhoneAuthDialog) {
        PhoneAuthDialog(
            onDismiss = { showPhoneAuthDialog = false }
        )
    }

    if (lockedPhoneTeaser != null) {
        val lockedPhone = lockedPhoneTeaser!!
        AlertDialog(
            onDismissRequest = { lockedPhoneTeaser = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFFFF3D00),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "هاتف ${lockedPhone.brand.uppercase()} ${lockedPhone.modelName} محمي 🔒",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                )
            },
            text = {
                Text(
                    text = "هذا الهاتف ينتمي لقائمة التوافقات الحصرية للمشتركين.\n\nاشترك بـ 1,500 د.ج فقط لفتح رمز الشاشة، سمك السلك، الحرارة والتوافقات لكافة الهواتف 👑",
                    style = MaterialTheme.typography.bodySmall.copy(
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        lockedPhoneTeaser = null
                        showPhoneAuthDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("تسجيل الدخول / تفعيل الاشتراك 📲", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { lockedPhoneTeaser = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    if (showQrScannerDialog) {
        QrScannerDialog(
            phonesList = phonesList,
            onDismiss = { showQrScannerDialog = false },
            onSelectPhoneForSearch = { modelName ->
                viewModel.onSearchQueryChanged(modelName)
                selectedScreenTab = 0
            },
            onOpenEquipmentStore = {
                selectedScreenTab = 1
            }
        )
    }
}
