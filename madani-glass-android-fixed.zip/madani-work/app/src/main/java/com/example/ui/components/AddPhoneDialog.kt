package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.db.PhoneEntity
import com.example.ui.language.Strings

@Composable
fun AddPhoneDialog(
    onDismiss: () -> Unit,
    onSavePhone: (PhoneEntity) -> Unit
) {
    var brand by remember { mutableStateOf("Samsung") }
    var modelName by remember { mutableStateOf("") }
    var modelCode by remember { mutableStateOf("") }
    var screenSizeText by remember { mutableStateOf("6.5") }
    var screenType by remember { mutableStateOf("PLS LCD") }
    var compatibleModels by remember { mutableStateOf("") }
    var cameraCutout by remember { mutableStateOf("V-Notch") }
    var tempText by remember { mutableStateOf("85") }
    var wireSize by remember { mutableStateOf("0.03 mm") }
    var userNotes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp))
                .testTag("add_phone_dialog"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "📱 " + Strings.get("add_device"),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                CustomTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = Strings.get("brand"),
                    testTag = "input_brand"
                )

                CustomTextField(
                    value = modelName,
                    onValueChange = { modelName = it },
                    label = Strings.get("model_name") + " *",
                    testTag = "input_model_name"
                )

                CustomTextField(
                    value = modelCode,
                    onValueChange = { modelCode = it },
                    label = Strings.get("model_code"),
                    testTag = "input_model_code"
                )

                CustomTextField(
                    value = screenSizeText,
                    onValueChange = { screenSizeText = it },
                    label = Strings.get("screen_size") + " (e.g. 6.5)",
                    testTag = "input_screen_size"
                )

                CustomTextField(
                    value = screenType,
                    onValueChange = { screenType = it },
                    label = Strings.get("screen_type") + " (e.g. AMOLED / LCD)",
                    testTag = "input_screen_type"
                )

                CustomTextField(
                    value = compatibleModels,
                    onValueChange = { compatibleModels = it },
                    label = Strings.get("compatible_models"),
                    testTag = "input_compatible_models"
                )

                CustomTextField(
                    value = cameraCutout,
                    onValueChange = { cameraCutout = it },
                    label = Strings.get("camera_notch") + " (Punch Hole, V-Notch)",
                    testTag = "input_camera_cutout"
                )

                CustomTextField(
                    value = userNotes,
                    onValueChange = { userNotes = it },
                    label = Strings.get("user_notes"),
                    testTag = "input_user_notes"
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("cancel_add_phone")
                    ) {
                        Text(Strings.get("cancel"))
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (modelName.isNotBlank()) {
                                val sizeDouble = screenSizeText.toDoubleOrNull() ?: 6.5
                                val tempInt = tempText.toIntOrNull() ?: 85
                                val newPhone = PhoneEntity(
                                    brand = brand.trim().ifEmpty { "Generic" },
                                    modelName = modelName.trim(),
                                    modelCode = modelCode.trim(),
                                    screenSizeInch = sizeDouble,
                                    screenType = screenType.trim().ifEmpty { "LCD" },
                                    compatibilityGroupId = "CUSTOM-${System.currentTimeMillis()}",
                                    compatibleModels = compatibleModels.trim().ifEmpty { modelName },
                                    glassType = "Glass + OCA",
                                    cameraCutout = cameraCutout.trim(),
                                    separationTempCelsius = tempInt,
                                    wireSizeMm = wireSize,
                                    userNotes = userNotes.trim()
                                )
                                onSavePhone(newPhone)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("save_add_phone")
                    ) {
                        Text(Strings.get("save"), color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    testTag: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, style = MaterialTheme.typography.bodySmall) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
            focusedLabelColor = MaterialTheme.colorScheme.primary
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag(testTag)
    )
}
