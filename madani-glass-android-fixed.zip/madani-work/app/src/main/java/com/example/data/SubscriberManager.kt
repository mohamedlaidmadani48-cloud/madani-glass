package com.example.data

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class SubscriberAccount(
    val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val phoneNumber: String,
    val registrationDate: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
    val subscriptionPlan: String = "شهري (1,500 د.ج)",
    val isActive: Boolean = true,
    val expiryDate: String = "2027-12-31",
    val isAdmin: Boolean = false
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("fullName", fullName)
            put("phoneNumber", phoneNumber)
            put("registrationDate", registrationDate)
            put("subscriptionPlan", subscriptionPlan)
            put("isActive", isActive)
            put("expiryDate", expiryDate)
            put("isAdmin", isAdmin)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): SubscriberAccount {
            return SubscriberAccount(
                id = obj.optString("id", UUID.randomUUID().toString()),
                fullName = obj.optString("fullName", "مشترك محلي"),
                phoneNumber = obj.optString("phoneNumber", "0550000000"),
                registrationDate = obj.optString("registrationDate", "2026-01-01"),
                subscriptionPlan = obj.optString("subscriptionPlan", "شهري (1,500 د.ج)"),
                isActive = obj.optBoolean("isActive", true),
                expiryDate = obj.optString("expiryDate", "2027-12-31"),
                isAdmin = obj.optBoolean("isAdmin", false)
            )
        }
    }
}

object SubscriberManager {
    private const val PREFS_NAME = "subscribers_manager_prefs"
    private const val KEY_SUBSCRIBERS_JSON = "subscribers_json_list"
    private const val KEY_CURRENT_USER_PHONE = "current_user_phone"

    val subscribersState = mutableStateOf<List<SubscriberAccount>>(emptyList())
    val currentUserState = mutableStateOf<SubscriberAccount?>(null)

    val defaultSubscribers = listOf(
        SubscriberAccount(
            id = "admin_1",
            fullName = "مدني جلاس (الحساب الإداري)",
            phoneNumber = "0550000000",
            registrationDate = "2026-01-01",
            subscriptionPlan = "حساب إداري دائم 👑",
            isActive = true,
            expiryDate = "2030-12-31",
            isAdmin = true
        ),
        SubscriberAccount(
            id = "sub_1",
            fullName = "محمد الأمين (فني صيانة - وهران)",
            phoneNumber = "0661234567",
            registrationDate = "2026-02-15",
            subscriptionPlan = "اشتراك سنوي (12,000 د.ج)",
            isActive = true,
            expiryDate = "2027-02-15",
            isAdmin = false
        ),
        SubscriberAccount(
            id = "sub_2",
            fullName = "كريم العربي (فني صيانة - قسنطينة)",
            phoneNumber = "0778899001",
            registrationDate = "2026-03-01",
            subscriptionPlan = "اشتراك شهري (1,500 د.ج)",
            isActive = true,
            expiryDate = "2026-10-01",
            isAdmin = false
        )
    )

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_SUBSCRIBERS_JSON, null)

        val list = mutableListOf<SubscriberAccount>()
        if (jsonStr.isNullOrEmpty()) {
            list.addAll(defaultSubscribers)
            saveList(context, list)
        } else {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    list.add(SubscriberAccount.fromJson(array.getJSONObject(i)))
                }
            } catch (e: Exception) {
                e.printStackTrace()
                list.addAll(defaultSubscribers)
            }
        }
        subscribersState.value = list

        val savedPhone = prefs.getString(KEY_CURRENT_USER_PHONE, null)
        if (!savedPhone.isNullOrEmpty()) {
            val found = list.find { cleanPhone(it.phoneNumber) == cleanPhone(savedPhone) }
            if (found != null) {
                currentUserState.value = found
            } else {
                // If not found in list, auto register default admin or user
                val adminAccount = list.find { it.isAdmin } ?: list.firstOrNull()
                currentUserState.value = adminAccount
            }
        } else {
            // Default logged in user for seamless experience
            currentUserState.value = list.firstOrNull { it.isAdmin } ?: list.firstOrNull()
        }
    }

    fun cleanPhone(phone: String): String {
        return phone.replace(" ", "").replace("-", "").replace("+213", "0")
    }

    private fun saveList(context: Context, list: List<SubscriberAccount>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        list.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_SUBSCRIBERS_JSON, array.toString()).apply()
        subscribersState.value = list
    }

    fun loginWithPhone(context: Context, rawPhone: String, rawName: String): SubscriberAccount {
        val phone = cleanPhone(rawPhone)
        val name = if (rawName.isBlank()) "مشترك $phone" else rawName.trim()

        val list = subscribersState.value.toMutableList()
        var user = list.find { cleanPhone(it.phoneNumber) == phone }

        if (user == null) {
            user = SubscriberAccount(
                fullName = name,
                phoneNumber = phone,
                subscriptionPlan = "اشتراك جديد (شهري)",
                isActive = true,
                expiryDate = "2027-12-31"
            )
            list.add(0, user)
            saveList(context, list)
        } else {
            if (rawName.isNotBlank() && user.fullName != name) {
                user = user.copy(fullName = name)
                val idx = list.indexOfFirst { it.id == user?.id }
                if (idx != -1) {
                    list[idx] = user
                    saveList(context, list)
                }
            }
        }

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_CURRENT_USER_PHONE, phone).apply()
        currentUserState.value = user
        return user
    }

    fun logout(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_CURRENT_USER_PHONE).apply()
        currentUserState.value = null
    }

    fun addOrUpdateSubscriber(context: Context, subscriber: SubscriberAccount) {
        val list = subscribersState.value.toMutableList()
        val idx = list.indexOfFirst { it.id == subscriber.id || cleanPhone(it.phoneNumber) == cleanPhone(subscriber.phoneNumber) }
        if (idx != -1) {
            list[idx] = subscriber
        } else {
            list.add(0, subscriber)
        }
        saveList(context, list)

        if (currentUserState.value?.id == subscriber.id || cleanPhone(currentUserState.value?.phoneNumber ?: "") == cleanPhone(subscriber.phoneNumber)) {
            currentUserState.value = subscriber
        }
    }

    fun toggleSubscriberActive(context: Context, id: String) {
        val list = subscribersState.value.toMutableList()
        val idx = list.indexOfFirst { it.id == id }
        if (idx != -1) {
            val updated = list[idx].copy(isActive = !list[idx].isActive)
            list[idx] = updated
            saveList(context, list)

            if (currentUserState.value?.id == id) {
                currentUserState.value = updated
            }
        }
    }

    fun deleteSubscriber(context: Context, id: String) {
        val list = subscribersState.value.toMutableList()
        val item = list.find { it.id == id }
        if (item != null) {
            list.remove(item)
            saveList(context, list)
            if (currentUserState.value?.id == id) {
                currentUserState.value = null
            }
        }
    }
}
