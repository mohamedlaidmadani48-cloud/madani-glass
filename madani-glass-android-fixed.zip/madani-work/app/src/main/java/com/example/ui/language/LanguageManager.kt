package com.example.ui.language

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf

enum class AppLanguage(val code: String, val displayName: String, val flag: String, val isRtl: Boolean) {
    ARABIC("ar", "العربية", "🇩🇿", true),
    ENGLISH("en", "English", "🇬🇧", false),
    FRENCH("fr", "Français", "🇫🇷", false)
}

object LanguageState {
    private val _currentLanguage = mutableStateOf(AppLanguage.ARABIC)
    val currentLanguage: State<AppLanguage> = _currentLanguage

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }
}
