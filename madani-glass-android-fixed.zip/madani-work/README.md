# Madani Glass — Android project

This is the original native Android version of Madani Glass (Kotlin + Jetpack Compose).

## Build

Requirements:
- Android Studio (current stable)
- JDK 17 or newer
- Android SDK Platform 36

Open the project root in Android Studio and let Gradle sync.

### Test APK

Use **Build > Build APK(s)** or run the `assembleRelease` Gradle task. The release build in this prepared project uses the standard Android debug signing key for local/testing installation.

**Important:** this signing is for testing only. Before publishing to Google Play, create/use your own private release keystore and configure a release signing configuration in Android Studio.

## Changes made for build reliability

- Removed dependency on a missing custom `my-upload-key.jks`.
- Removed the custom `debugConfig` keystore.
- Release now uses the standard Android debug signing key for local/test APK generation.
- Removed unused Google Services/Secrets/Firebase build plugins and dependencies that were not referenced by the app source.
- Kept the local Room database and its seed data.
- Fixed Room initial-data seeding so it happens after the database instance is assigned.
- Preserved the original app package/application ID and UI resources.
