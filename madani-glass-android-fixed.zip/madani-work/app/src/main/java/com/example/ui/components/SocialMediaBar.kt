package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.SocialLinksManager
import com.example.ui.language.Strings

@Composable
fun HeaderSocialQuickIcons(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val links = SocialLinksManager.currentLinks.value

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Facebook Button
        SocialIconButton(
            iconRes = R.drawable.ic_facebook,
            contentDescription = "Facebook Page",
            backgroundColor = Color(0xFF1877F2),
            testTag = "social_facebook_icon_btn",
            onClick = {
                openSocialUrl(
                    context,
                    url = links.facebookUrl,
                    platformName = "Facebook"
                )
            }
        )

        // TikTok Button
        SocialIconButton(
            iconRes = R.drawable.ic_tiktok,
            contentDescription = "TikTok Account",
            backgroundColor = Color(0xFF000000),
            borderColor = Color(0xFF00F2FE),
            testTag = "social_tiktok_icon_btn",
            onClick = {
                openSocialUrl(
                    context,
                    url = links.tiktokUrl,
                    platformName = "TikTok"
                )
            }
        )

        // YouTube Button
        SocialIconButton(
            iconRes = R.drawable.ic_youtube,
            contentDescription = "YouTube Channel",
            backgroundColor = Color(0xFFFF0000),
            testTag = "social_youtube_icon_btn",
            onClick = {
                openSocialUrl(
                    context,
                    url = links.youtubeUrl,
                    platformName = "YouTube"
                )
            }
        )
    }
}

@Composable
private fun SocialIconButton(
    iconRes: Int,
    contentDescription: String,
    backgroundColor: Color,
    borderColor: Color? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .clickable { onClick() }
            .testTag(testTag),
        color = backgroundColor,
        shape = CircleShape,
        border = borderColor?.let { androidx.compose.foundation.BorderStroke(1.dp, it) }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(4.dp)
        ) {
            Image(
                painter = painterResource(id = iconRes),
                contentDescription = contentDescription,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun SocialMediaCardSection(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val links = SocialLinksManager.currentLinks.value
    var showEditDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .testTag("social_media_card_section"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
        )
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "📱 " + Strings.get("social_channels_title"),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = Strings.get("social_channels_sub"),
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    )
                }

                // Edit Accounts Button
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showEditDialog = true }
                        .testTag("open_edit_social_dialog_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Links",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = Strings.get("edit_social_links"),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3 Platforms Cards Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Facebook Item
                SocialPlatformTile(
                    modifier = Modifier.weight(1f),
                    title = "Facebook",
                    subtitle = "شروحات وصور",
                    badgeText = "متابعة",
                    iconRes = R.drawable.ic_facebook,
                    accentColor = Color(0xFF1877F2),
                    onClick = {
                        openSocialUrl(context, links.facebookUrl, "Facebook")
                    }
                )

                // TikTok Item
                SocialPlatformTile(
                    modifier = Modifier.weight(1f),
                    title = "TikTok",
                    subtitle = "مقاطع سريعة",
                    badgeText = "متابعة",
                    iconRes = R.drawable.ic_tiktok,
                    accentColor = Color(0xFF000000),
                    onClick = {
                        openSocialUrl(context, links.tiktokUrl, "TikTok")
                    }
                )

                // YouTube Item
                SocialPlatformTile(
                    modifier = Modifier.weight(1f),
                    title = "YouTube",
                    subtitle = "فيديوهات مكثفة",
                    badgeText = "متابعة",
                    iconRes = R.drawable.ic_youtube,
                    accentColor = Color(0xFFFF0000),
                    onClick = {
                        openSocialUrl(context, links.youtubeUrl, "YouTube")
                    }
                )
            }
        }
    }

    if (showEditDialog) {
        EditSocialLinksDialog(
            onDismiss = { showEditDialog = false }
        )
    }
}

@Composable
fun EditSocialLinksDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val currentLinks = SocialLinksManager.currentLinks.value

    var fbUrl by remember { mutableStateOf(currentLinks.facebookUrl) }
    var tiktokUrl by remember { mutableStateOf(currentLinks.tiktokUrl) }
    var youtubeUrl by remember { mutableStateOf(currentLinks.youtubeUrl) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.get("edit_social_links"),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Facebook Input
                OutlinedTextField(
                    value = fbUrl,
                    onValueChange = { fbUrl = it },
                    label = { Text(Strings.get("facebook_url")) },
                    leadingIcon = {
                        Image(
                            painter = painterResource(id = R.drawable.ic_facebook),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_fb_url"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // TikTok Input
                OutlinedTextField(
                    value = tiktokUrl,
                    onValueChange = { tiktokUrl = it },
                    label = { Text(Strings.get("tiktok_url")) },
                    leadingIcon = {
                        Image(
                            painter = painterResource(id = R.drawable.ic_tiktok),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tiktok_url"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // YouTube Input
                OutlinedTextField(
                    value = youtubeUrl,
                    onValueChange = { youtubeUrl = it },
                    label = { Text(Strings.get("youtube_url")) },
                    leadingIcon = {
                        Image(
                            painter = painterResource(id = R.drawable.ic_youtube),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_youtube_url"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Save Button
                Button(
                    onClick = {
                        SocialLinksManager.saveLinks(
                            context = context,
                            facebook = fbUrl,
                            tiktok = tiktokUrl,
                            youtube = youtubeUrl
                        )
                        Toast.makeText(context, Strings.get("links_saved_success"), Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_social_links_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Strings.get("save_changes"),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun SocialPlatformTile(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    badgeText: String,
    iconRes: Int,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 7.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = CircleShape,
                color = accentColor.copy(alpha = 0.12f),
                modifier = Modifier.size(28.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Image(
                        painter = painterResource(id = iconRes),
                        contentDescription = title,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )

            Spacer(modifier = Modifier.height(3.dp))

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = accentColor.copy(alpha = 0.15f)
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (accentColor == Color.Black) MaterialTheme.colorScheme.onSurface else accentColor
                    ),
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                )
            }
        }
    }
}

private fun openSocialUrl(context: Context, url: String, platformName: String) {
    try {
        val targetUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) "https://$url" else url
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "جاري فتح صفحة $platformName...", Toast.LENGTH_SHORT).show()
    }
}

