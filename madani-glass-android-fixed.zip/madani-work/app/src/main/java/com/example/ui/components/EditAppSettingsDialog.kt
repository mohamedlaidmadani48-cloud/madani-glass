package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.AppSettingsManager
import com.example.ui.language.Strings

@Composable
fun EditAppSettingsDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val current = AppSettingsManager.currentSettings.value

    var titleText by remember { mutableStateOf(current.appTitle) }
    var subtitleText by remember { mutableStateOf(current.appSubtitle) }
    var phoneText by remember { mutableStateOf(current.phoneNumber) }
    var addressText by remember { mutableStateOf(current.storeAddress) }
    var announcementText by remember { mutableStateOf(current.announcementText) }

    var isSubEnabled by remember { mutableStateOf(current.isSubscriptionModeEnabled) }
    var monthlyPriceText by remember { mutableStateOf(current.monthlySubPriceDzd) }
    var yearlyPriceText by remember { mutableStateOf(current.yearlySubPriceDzd) }
    var baridiMobText by remember { mutableStateOf(current.baridiMobRip) }
    var visaText by remember { mutableStateOf(current.visaCardDetails) }
    var usdtText by remember { mutableStateOf(current.usdtWalletAddress) }

    var showManageProducts by remember { mutableStateOf(false) }
    var showManageVideos by remember { mutableStateOf(false) }
    var showSubscribersList by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.get("edit_app_info"),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // App Title Field
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text(Strings.get("app_title_label")) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Title, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_app_title"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // App Subtitle Field
                OutlinedTextField(
                    value = subtitleText,
                    onValueChange = { subtitleText = it },
                    label = { Text(Strings.get("app_subtitle_label")) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_app_subtitle"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Contact Phone Field
                OutlinedTextField(
                    value = phoneText,
                    onValueChange = { phoneText = it },
                    label = { Text(Strings.get("contact_phone_label")) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_app_phone"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Store Address Field
                OutlinedTextField(
                    value = addressText,
                    onValueChange = { addressText = it },
                    label = { Text(Strings.get("store_address_label")) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Business, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_app_address"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Announcement Banner Field
                OutlinedTextField(
                    value = announcementText,
                    onValueChange = { announcementText = it },
                    label = { Text(Strings.get("announcement_banner_label")) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_app_announcement"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Subscription & Payment Settings Card Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CardMembership,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "وضع الاشتراكات ووسائل الدفع",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            Switch(
                                checked = isSubEnabled,
                                onCheckedChange = { isSubEnabled = it },
                                modifier = Modifier.testTag("toggle_subscription_mode_switch")
                            )
                        }

                        Text(
                            text = if (isSubEnabled) "حالة المتجر: مفعل بوضع الاشتراكات الشهري/السنوي 🔒" else "حالة المتجر: تصفح وشراء مجاني 🟢",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 11.sp,
                                color = if (isSubEnabled) Color(0xFFFF3D00) else Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Monthly Price Field
                        OutlinedTextField(
                            value = monthlyPriceText,
                            onValueChange = { monthlyPriceText = it },
                            label = { Text("سعر الاشتراك الشهري (Monthly)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CardMembership, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("input_monthly_price"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Yearly Price Field
                        OutlinedTextField(
                            value = yearlyPriceText,
                            onValueChange = { yearlyPriceText = it },
                            label = { Text("سعر الاشتراك السنوي (Yearly)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CardMembership, contentDescription = null, tint = Color(0xFFFF9100))
                            },
                            modifier = Modifier.fillMaxWidth().testTag("input_yearly_price"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "💳 إعدادات حسابات ووسائل الدفع المقبولة:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // BaridiMob RIP Field
                        OutlinedTextField(
                            value = baridiMobText,
                            onValueChange = { baridiMobText = it },
                            label = { Text("📮 بريدي موب (BaridiMob / RIP / CCP)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = Color(0xFF00C853))
                            },
                            modifier = Modifier.fillMaxWidth().testTag("input_baridimob_rip"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Visa Card Details
                        OutlinedTextField(
                            value = visaText,
                            onValueChange = { visaText = it },
                            label = { Text("💳 فيزا كارت / ماستركارد (Visa Details / Link)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = Color(0xFF2979FF))
                            },
                            modifier = Modifier.fillMaxWidth().testTag("input_visa_details"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // USDT Crypto Wallet
                        OutlinedTextField(
                            value = usdtText,
                            onValueChange = { usdtText = it },
                            label = { Text("🪙 محفظة USDT (Crypto Address TRC20)") },
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.CurrencyBitcoin, contentDescription = null, tint = Color(0xFFFFD600))
                            },
                            modifier = Modifier.fillMaxWidth().testTag("input_usdt_address"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showManageProducts = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🛠️ تعديل وإضافة منتجات المتجر والعتاد", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { showManageVideos = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🎬 تعديل وإدارة الفيديوهات التعليمية", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = { showSubscribersList = true },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CardMembership, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("👥 مشاهدة وإدارة حسابات المشتركين", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Save Changes Button
                Button(
                    onClick = {
                        AppSettingsManager.saveSettings(
                            context = context,
                            title = titleText,
                            subtitle = subtitleText,
                            phone = phoneText,
                            address = addressText,
                            announcement = announcementText,
                            isSubscriptionEnabled = isSubEnabled,
                            monthlyPrice = monthlyPriceText,
                            yearlyPrice = yearlyPriceText,
                            baridiMob = baridiMobText,
                            visa = visaText,
                            usdt = usdtText
                        )
                        Toast.makeText(context, Strings.get("app_info_saved_success"), Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_app_settings_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Strings.get("save_changes"),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }

    if (showManageProducts) {
        ManageProductsDialog(
            onDismiss = { showManageProducts = false }
        )
    }

    if (showManageVideos) {
        ManageVideosDialog(
            onDismiss = { showManageVideos = false }
        )
    }

    if (showSubscribersList) {
        SubscribersListDialog(
            onDismiss = { showSubscribersList = false }
        )
    }
}

