package com.example.data.model

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class EquipmentCategory(val titleAr: String, val titleEn: String, val titleFr: String, val emoji: String) {
    ALL("الكل", "All", "Tous", "📦"),
    MACHINES("آلات وسخانات", "Machines & Separators", "Machines", "⚙️"),
    CONSUMABLES("أسلاك وسوائل", "Wires & Solvents", "Consommables", "🧪"),
    OCA_GLASS("باغات و OCA", "Glass & OCA Sheets", "Vitres & OCA", "📱"),
    TOOLS("قوالب ودريل", "Molds & Tools", "Moules & Outils", "🔧")
}

data class EquipmentProduct(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val nameFr: String,
    val category: EquipmentCategory,
    val priceDzd: Int,
    val originalPriceDzd: Int? = null,
    val badgeAr: String,
    val badgeEn: String,
    val badgeFr: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val descriptionFr: String,
    val specsAr: List<String>,
    val specsEn: List<String>,
    val specsFr: List<String>,
    val emoji: String = "🔧",
    val imageUrl: String = "",
    val isHotDeal: Boolean = false
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("nameAr", nameAr)
        obj.put("nameEn", nameEn)
        obj.put("nameFr", nameFr)
        obj.put("category", category.name)
        obj.put("priceDzd", priceDzd)
        obj.put("originalPriceDzd", originalPriceDzd ?: -1)
        obj.put("badgeAr", badgeAr)
        obj.put("badgeEn", badgeEn)
        obj.put("badgeFr", badgeFr)
        obj.put("descriptionAr", descriptionAr)
        obj.put("descriptionEn", descriptionEn)
        obj.put("descriptionFr", descriptionFr)
        val specsArr = JSONArray()
        specsAr.forEach { specsArr.put(it) }
        obj.put("specsAr", specsArr)
        obj.put("emoji", emoji)
        obj.put("imageUrl", imageUrl)
        obj.put("isHotDeal", isHotDeal)
        return obj
    }

    companion object {
        fun fromJson(obj: JSONObject): EquipmentProduct {
            val catName = obj.optString("category", "TOOLS")
            val cat = try { EquipmentCategory.valueOf(catName) } catch (e: Exception) { EquipmentCategory.TOOLS }
            val origPrice = obj.optInt("originalPriceDzd", -1)
            val specsList = mutableListOf<String>()
            val arr = obj.optJSONArray("specsAr")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    specsList.add(arr.getString(i))
                }
            }
            return EquipmentProduct(
                id = obj.optString("id", UUID.randomUUID().toString()),
                nameAr = obj.optString("nameAr", "منتج جديد"),
                nameEn = obj.optString("nameEn", "New Product"),
                nameFr = obj.optString("nameFr", "Nouveau Produit"),
                category = cat,
                priceDzd = obj.optInt("priceDzd", 1000),
                originalPriceDzd = if (origPrice > 0) origPrice else null,
                badgeAr = obj.optString("badgeAr", "متوفر 🔥"),
                badgeEn = obj.optString("badgeEn", "Available 🔥"),
                badgeFr = obj.optString("badgeFr", "Disponible 🔥"),
                descriptionAr = obj.optString("descriptionAr", "وصف المنتج"),
                descriptionEn = obj.optString("descriptionEn", "Product description"),
                descriptionFr = obj.optString("descriptionFr", "Description du produit"),
                specsAr = specsList.ifEmpty { listOf("جودة عالية") },
                specsEn = listOf("High quality"),
                specsFr = listOf("Haute qualité"),
                emoji = obj.optString("emoji", "🔧"),
                imageUrl = obj.optString("imageUrl", ""),
                isHotDeal = obj.optBoolean("isHotDeal", false)
            )
        }
    }
}

object EquipmentCatalogData {
    private const val PREFS_NAME = "equipment_catalog_prefs"
    private const val KEY_PRODUCTS_JSON = "custom_products_json"

    val productsState = mutableStateOf<List<EquipmentProduct>>(emptyList())

    val defaultProducts = listOf(
        EquipmentProduct(
            id = "prod_1",
            nameAr = "آلة تسخين وشفط الشاشات Sunshine S-918K (Double Pump)",
            nameEn = "Sunshine S-918K Vacuum Heating Separator (Double Pump)",
            nameFr = "Séparateur Chauffant sous Vide Sunshine S-918K",
            category = EquipmentCategory.MACHINES,
            priceDzd = 14500,
            originalPriceDzd = 16800,
            badgeAr = "الأكثر مبيعاً ⚡",
            badgeEn = "Best Seller ⚡",
            badgeFr = "Meilleure vente ⚡",
            descriptionAr = "سخان ومضخة شفط مزدوجة قوية جداً لتثبيت الشاشات المنحنية والمستقيمة أثناء قص السلك بسهولة تامة.",
            descriptionEn = "High power dual-pump vacuum heating separator pad for curved and flat screens.",
            descriptionFr = "Séparateur sous vide puissant à double pompe pour écrans plats et incurvés.",
            specsAr = listOf(
                "قوة تسخين دقيقة حتى 120°C",
                "مضخة شفط ثنائية عالية الثبات (Dual Vacuum Pump)",
                "سطح ألومنيوم أنودايز مقاوم للخدوش 8.5 بوصة",
                "منفذ USB مدمج للشحن والفحص"
            ),
            specsEn = listOf("Precise temp up to 120°C", "Dual vacuum pump", "8.5 inch plate"),
            specsFr = listOf("Contrôle temp 120°C", "Double pompe", "Plaque 8.5 pouces"),
            emoji = "🔥",
            isHotDeal = true
        ),

        EquipmentProduct(
            id = "prod_2",
            nameAr = "مكبس وغرفة تفريغ فقاعات OCA المدمجة Forward RMA 303 Mini",
            nameEn = "Forward RMA 303 Mini 2-in-1 OCA Laminator & Autoclave",
            nameFr = "Plastifieuse & Autoclave 2 en 1 Forward RMA 303",
            category = EquipmentCategory.MACHINES,
            priceDzd = 128000,
            originalPriceDzd = 140000,
            badgeAr = "ضمان سنة 🛡️",
            badgeEn = "1 Year Warranty 🛡️",
            badgeFr = "Garantie 1 an 🛡️",
            descriptionAr = "جهاز احترافي 2 في 1 يجمع بين مكبس الـ OCA الذكي وغرفة تفريغ الفقاعات (Autoclave) لشاشات الأيفون والسامسونج.",
            descriptionEn = "All-in-one smart OCA laminator and de-bubbler chamber for iPhone and Edge screens.",
            descriptionFr = "Machine 2-en-1 intelligente pour stratification OCA et élimination des bulles.",
            specsAr = listOf(
                "ضغط كبس بدقة 0.01 MPa عبر شاشة لمس",
                "غرفة Autoclave تتسع لـ 4 شاشات دفعة واحدة",
                "بدون اهتزاز وصامت",
                "يدعم الشاشات حتى 11 بوصة"
            ),
            specsEn = listOf("Touchscreen control", "Fits 4 phones", "Silent operation"),
            specsFr = listOf("Écran tactile", "Pour 4 téléphones", "Silencieux"),
            emoji = "🏗️",
            isHotDeal = true
        ),

        EquipmentProduct(
            id = "prod_3",
            nameAr = "سلك قطع باغات فولاذي متين QianLi 0.028mm (بكرة 100 متر)",
            nameEn = "QianLi 0.028mm High-Tenacity Separation Wire (100m)",
            nameFr = "Fil de Séparation Haute Résistance QianLi 0.028mm (100m)",
            category = EquipmentCategory.CONSUMABLES,
            priceDzd = 1200,
            originalPriceDzd = 1500,
            badgeAr = "فائق الدقة ✨",
            badgeEn = "Ultra Thin ✨",
            badgeFr = "Ultra Fin ✨",
            descriptionAr = "سلك موليغيدنيوم صلب ناعم جداً بسُمك 0.028مم يقطع غراء OCA بدون جرح طبقة البولاريزر الحساسة.",
            descriptionEn = "Ultra-thin 0.028mm molybdenum cutting wire, high tensile strength for OLED screen cutting.",
            descriptionFr = "Fil molybdène ultra-fin 0.028mm pour découpe précise sans abîmer le polariseur.",
            specsAr = listOf("سمك متناهي الدقة 0.028mm", "مقاوم للقطع والشد العالي", "طول البكرة: 100 متر"),
            specsEn = listOf("0.028mm thickness", "High tensile strength", "100m length"),
            specsFr = listOf("Épaisseur 0.028mm", "Haute résistance", "Longueur 100m"),
            emoji = "🧵"
        ),

        EquipmentProduct(
            id = "prod_4",
            nameAr = "دريل إزالة الغراء الكهربائي Mechanic IR10 PRO (قابلة للشحن)",
            nameEn = "Mechanic IR10 PRO Rechargeable OCA Glue Remover Motor",
            nameFr = "Outil Rotatif Électrique Mechanic IR10 PRO Enlèvement OCA",
            category = EquipmentCategory.TOOLS,
            priceDzd = 4800,
            originalPriceDzd = 5500,
            badgeAr = "بطارية تدوم طويلاً 🔋",
            badgeEn = "Long Battery 🔋",
            badgeFr = "Batterie longue durée 🔋",
            descriptionAr = "دريل يدوي خفيف الوزن مع 4 سرعات مختلفة ورؤوس تنظيف متعددة لإزالة غراء الشاشات بسرعة وسلاسة.",
            descriptionEn = "Handheld electric glue remover with 4 speed settings and LED dust lighting.",
            descriptionFr = "Enleveur de colle électrique rechargeable avec 4 vitesses et éclairage LED.",
            specsAr = listOf("4 مستويات سرعة", "إضاءة LED خضراء كاشفة للغبار", "بطارية ليثيوم شحن Type-C"),
            specsEn = listOf("4 speed levels", "Green LED light", "Type-C battery"),
            specsFr = listOf("4 vitesses", "Lumière LED verte", "Recharge Type-C"),
            emoji = "🪛"
        ),

        EquipmentProduct(
            id = "prod_5",
            nameAr = "سائل مذيب وتنظيف غراء الـ OCA سعة 8333 (1 لتر)",
            nameEn = "Mechanic 8333 Professional OCA Glue Cleaner Solvent (1L)",
            nameFr = "Solvant Nettoyant Colle OCA Mechanic 8333 (1L)",
            category = EquipmentCategory.CONSUMABLES,
            priceDzd = 2200,
            originalPriceDzd = 2600,
            badgeAr = "سريع التفاعل 🧪",
            badgeEn = "Fast Acting 🧪",
            badgeFr = "Action rapide 🧪",
            descriptionAr = "مذيب كيميائي آمن على طبقات الشاشة يفكك غراء OCA القديم خلال ثوانٍ بدون ترك آثار زيتيّة.",
            descriptionEn = "Professional chemical solvent that dissolves hardened OCA adhesive instantly without LCD damage.",
            descriptionFr = "Solvant chimique professionnel dissolvant la colle OCA rapidement.",
            specsAr = listOf("حجم كبير 1000 مل", "آمن على البولاريزر", "سريع التبخر"),
            specsEn = listOf("1000ml size", "Safe for polarizers", "Fast evaporating"),
            specsFr = listOf("Format 1000ml", "Sûr pour polariseur", "Évaporation rapide"),
            emoji = "🧪"
        ),

        EquipmentProduct(
            id = "prod_6",
            nameAr = "طقم قوالب محاذاة ألومنيوم عالمي لشاشات iPhone (11 إلى 15 Pro Max)",
            nameEn = "Universal Aluminum Mold Set for iPhone Glass Lamination (11-15 Pro Max)",
            nameFr = "Kit Moules d'Alignement Aluminium pour iPhone (11 à 15 Pro Max)",
            category = EquipmentCategory.TOOLS,
            priceDzd = 18500,
            originalPriceDzd = 22000,
            badgeAr = "دقة متناهية 🎯",
            badgeEn = "High Precision 🎯",
            badgeFr = "Haute Précision 🎯",
            descriptionAr = "قوالب ألومنيوم معالجة بميكرونات الدقة لتطابق الزجاج الجديد مع الشاشة تماماً بدون ميلان.",
            descriptionEn = "Precision-machined aluminum alignment molds for perfect glass positioning.",
            descriptionFr = "Moules en aluminium usinés avec précision pour centrage parfait de la vitre.",
            specsAr = listOf("يشمل 12 قالب للآيفون", "مقاوم للصدأ والحرارة", "تثبيت مغناطيسي"),
            specsEn = listOf("Includes 12 molds", "Heat resistant", "Magnetic locking"),
            specsFr = listOf("12 moules inclus", "Résistant chaleur", "Fixation magnétique"),
            emoji = "📐"
        )
    )

    val products: List<EquipmentProduct>
        get() = if (productsState.value.isNotEmpty()) productsState.value else defaultProducts

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_PRODUCTS_JSON, null)
        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                val loadedList = mutableListOf<EquipmentProduct>()
                for (i in 0 until array.length()) {
                    loadedList.add(EquipmentProduct.fromJson(array.getJSONObject(i)))
                }
                if (loadedList.isNotEmpty()) {
                    productsState.value = loadedList
                    return
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        productsState.value = defaultProducts
    }

    private fun saveList(context: Context, list: List<EquipmentProduct>) {
        val array = JSONArray()
        list.forEach { array.put(it.toJson()) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PRODUCTS_JSON, array.toString())
            .apply()
        productsState.value = list
    }

    fun addProduct(context: Context, product: EquipmentProduct) {
        val current = products.toMutableList()
        current.add(0, product)
        saveList(context, current)
    }

    fun updateProduct(context: Context, updated: EquipmentProduct) {
        val current = products.toMutableList()
        val index = current.indexOfFirst { it.id == updated.id }
        if (index != -1) {
            current[index] = updated
            saveList(context, current)
        }
    }

    fun deleteProduct(context: Context, productId: String) {
        val current = products.filter { it.id != productId }
        saveList(context, current)
    }

    fun resetToDefaults(context: Context) {
        saveList(context, defaultProducts)
    }
}
