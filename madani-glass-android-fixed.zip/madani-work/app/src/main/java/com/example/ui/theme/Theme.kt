package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = WorkshopDarkBackground,
    primaryContainer = WorkshopDarkCard,
    onPrimaryContainer = NeonCyan,
    secondary = PhosphorEmerald,
    onSecondary = WorkshopDarkBackground,
    background = WorkshopDarkBackground,
    onBackground = HighContrastText,
    surface = WorkshopDarkSurface,
    onSurface = HighContrastText,
    surfaceVariant = WorkshopDarkCard,
    onSurfaceVariant = SubtitleText,
    outline = WorkshopDarkCardBorder
)

@Composable
fun MadaniGlassTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Keep backwards-compatibility alias for template
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MadaniGlassTheme(darkTheme = darkTheme, content = content)
}
