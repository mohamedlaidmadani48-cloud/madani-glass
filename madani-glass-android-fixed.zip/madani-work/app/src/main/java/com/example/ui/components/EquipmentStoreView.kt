package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.EquipmentCatalogData
import com.example.data.model.EquipmentCategory
import com.example.data.model.EquipmentProduct
import com.example.ui.language.AppLanguage
import com.example.ui.language.LanguageState
import com.example.ui.language.Strings

import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.example.data.AppSettingsManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EquipmentStoreView(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentLang = LanguageState.currentLanguage.value
    val appCustomSettings = AppSettingsManager.currentSettings.value

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(EquipmentCategory.ALL) }

    // Cart items state map: productId -> quantity
    val cartItems = remember { mutableStateMapOf<String, Int>() }
    var showCartSheet by remember { mutableStateOf(false) }
    var showSubscriptionDialog by remember { mutableStateOf(false) }
    var showManageProductsDialog by remember { mutableStateOf(false) }
    var selectedProductForDetail by remember { mutableStateOf<EquipmentProduct?>(null) }

    val allProducts = EquipmentCatalogData.products

    val filteredProducts = remember(searchQuery, selectedCategory, allProducts) {
        allProducts.filter { product ->
            val matchesCategory = (selectedCategory == EquipmentCategory.ALL || product.category == selectedCategory)
            val name = when (currentLang) {
                AppLanguage.ARABIC -> product.nameAr
                AppLanguage.ENGLISH -> product.nameEn
                AppLanguage.FRENCH -> product.nameFr
            }
            val matchesSearch = searchQuery.isBlank() ||
                    name.contains(searchQuery, ignoreCase = true) ||
                    product.descriptionAr.contains(searchQuery, ignoreCase = true) ||
                    product.descriptionEn.contains(searchQuery, ignoreCase = true)

            matchesCategory && matchesSearch
        }
    }

    val totalCartCount = cartItems.values.sum()
    val totalCartPrice = cartItems.entries.sumOf { (id, qty) ->
        val prod = allProducts.find { it.id == id }
        (prod?.priceDzd ?: 0) * qty
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Store Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp)),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_store_banner_1784972594906),
                        contentDescription = "Equipment Store Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.3f),
                                        Color.Black.copy(alpha = 0.85f)
                                    )
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFFF3D00)
                        ) {
                            Text(
                                text = "🚚 " + Strings.get("fast_delivery"),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = Strings.get("store_title"),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )

                        Text(
                            text = Strings.get("store_subtitle"),
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.LightGray
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Subscription & Payment Methods Quick Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { showSubscriptionDialog = true }
                    .testTag("open_subscription_hub_btn"),
                colors = CardDefaults.cardColors(
                    containerColor = if (appCustomSettings.isSubscriptionModeEnabled) Color(0xFFFF3D00).copy(alpha = 0.12f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (appCustomSettings.isSubscriptionModeEnabled) Color(0xFFFF3D00) else MaterialTheme.colorScheme.primary
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (appCustomSettings.isSubscriptionModeEnabled) Color(0xFFFF3D00) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CardMembership,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = if (appCustomSettings.isSubscriptionModeEnabled) "👑 وضع الاشتراك المميز والرفع للسنوي/الشهري" else "💳 خطط الاشتراكات ووسائل الدفع المقبولة",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "دفع عبر: 📮 بريدي موب | 💳 فيزا كارت | 🪙 USDT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = "اشتراك / دفع",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar & Manage Products Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("store_search_input"),
                    placeholder = {
                        Text(
                            "بحث عن آلة سخان، مكبس...",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showManageProductsDialog = true }
                        .testTag("open_manage_products_modal")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Manage",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "إدارة",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Selector Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(EquipmentCategory.values()) { category ->
                    val isSelected = selectedCategory == category
                    val title = when (currentLang) {
                        AppLanguage.ARABIC -> category.titleAr
                        AppLanguage.ENGLISH -> category.titleEn
                        AppLanguage.FRENCH -> category.titleFr
                    }

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { selectedCategory = category }
                            .testTag("category_chip_${category.name}"),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(category.emoji, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Products List Grid
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredProducts) { product ->
                    ProductCardItem(
                        product = product,
                        currentLang = currentLang,
                        cartQuantity = cartItems[product.id] ?: 0,
                        onAddToCart = {
                            val currentQty = cartItems[product.id] ?: 0
                            cartItems[product.id] = currentQty + 1
                            Toast.makeText(context, "تمت إضافة المنتج للسلة 🛒", Toast.LENGTH_SHORT).show()
                        },
                        onCardClick = { selectedProductForDetail = product }
                    )
                }
            }
        }

        // Floating Cart Button
        if (totalCartCount > 0) {
            FloatingActionButton(
                onClick = { showCartSheet = true },
                containerColor = Color(0xFFFF3D00),
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("floating_cart_fab")
            ) {
                BadgedBox(
                    badge = {
                        Badge(containerColor = Color.White, contentColor = Color(0xFFFF3D00)) {
                            Text(totalCartCount.toString(), fontWeight = FontWeight.Bold)
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Cart",
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }

    // Product Detail Dialog
    selectedProductForDetail?.let { product ->
        ProductDetailModal(
            product = product,
            currentLang = currentLang,
            onDismiss = { selectedProductForDetail = null },
            onAddToCart = {
                val currentQty = cartItems[product.id] ?: 0
                cartItems[product.id] = currentQty + 1
                Toast.makeText(context, "تمت إضافة المنتج للسلة 🛒", Toast.LENGTH_SHORT).show()
                selectedProductForDetail = null
            }
        )
    }

    // Cart Order Sheet
    if (showCartSheet) {
        OrderCartSheet(
            cartItemsMap = cartItems,
            allProducts = allProducts,
            currentLang = currentLang,
            onDismiss = { showCartSheet = false },
            onUpdateQuantity = { id, newQty ->
                if (newQty <= 0) cartItems.remove(id) else cartItems[id] = newQty
            },
            onClearCart = { cartItems.clear(); showCartSheet = false }
        )
    }

    // Subscription & Payment Modal
    if (showSubscriptionDialog) {
        SubscriptionPaymentModal(
            onDismiss = { showSubscriptionDialog = false }
        )
    }

    // Manage Products Modal
    if (showManageProductsDialog) {
        ManageProductsDialog(
            onDismiss = { showManageProductsDialog = false }
        )
    }
}

@Composable
private fun ProductCardItem(
    product: EquipmentProduct,
    currentLang: AppLanguage,
    cartQuantity: Int,
    onAddToCart: () -> Unit,
    onCardClick: () -> Unit
) {
    val name = when (currentLang) {
        AppLanguage.ARABIC -> product.nameAr
        AppLanguage.ENGLISH -> product.nameEn
        AppLanguage.FRENCH -> product.nameFr
    }

    val description = when (currentLang) {
        AppLanguage.ARABIC -> product.descriptionAr
        AppLanguage.ENGLISH -> product.descriptionEn
        AppLanguage.FRENCH -> product.descriptionFr
    }

    val badge = when (currentLang) {
        AppLanguage.ARABIC -> product.badgeAr
        AppLanguage.ENGLISH -> product.badgeEn
        AppLanguage.FRENCH -> product.badgeFr
    }

    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val localPath = saveProductImageToInternalStorage(context, uri)
            EquipmentCatalogData.updateProduct(context, product.copy(imageUrl = localPath))
            Toast.makeText(context, "تم تغيير صورة المنتج بنجاح 🖼️", Toast.LENGTH_SHORT).show()
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onCardClick() }
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                    ) {
                        if (product.imageUrl.isNotBlank()) {
                            AsyncImage(
                                model = product.imageUrl,
                                contentDescription = name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        } else {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                modifier = Modifier.size(52.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(product.emoji, fontSize = 24.sp)
                                }
                            }
                        }

                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(20.dp)
                                .align(Alignment.BottomEnd)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "تغيير الصورة",
                                    tint = Color.White,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (product.isHotDeal) Color(0xFFFF3D00).copy(alpha = 0.15f) else MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = badge,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (product.isHotDeal) Color(0xFFFF3D00) else MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Specs Bullet Summary
            val specsList = when (currentLang) {
                AppLanguage.ARABIC -> product.specsAr
                AppLanguage.ENGLISH -> product.specsEn
                AppLanguage.FRENCH -> product.specsFr
            }

            if (specsList.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    specsList.take(2).forEach { spec ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = "• $spec",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // Price and Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${product.priceDzd} ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = Strings.get("currency_dzd"),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    product.originalPriceDzd?.let { orig ->
                        Text(
                            text = "$orig ${Strings.get("currency_dzd")}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.Gray,
                                textDecoration = TextDecoration.LineThrough
                            )
                        )
                    }
                }

                Button(
                    onClick = onAddToCart,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_to_cart_${product.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (cartQuantity > 0) "($cartQuantity) " + Strings.get("add_to_cart") else Strings.get("add_to_cart"),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun ProductDetailModal(
    product: EquipmentProduct,
    currentLang: AppLanguage,
    onDismiss: () -> Unit,
    onAddToCart: () -> Unit
) {
    val name = when (currentLang) {
        AppLanguage.ARABIC -> product.nameAr
        AppLanguage.ENGLISH -> product.nameEn
        AppLanguage.FRENCH -> product.nameFr
    }

    val description = when (currentLang) {
        AppLanguage.ARABIC -> product.descriptionAr
        AppLanguage.ENGLISH -> product.descriptionEn
        AppLanguage.FRENCH -> product.descriptionFr
    }

    val specs = when (currentLang) {
        AppLanguage.ARABIC -> product.specsAr
        AppLanguage.ENGLISH -> product.specsEn
        AppLanguage.FRENCH -> product.specsFr
    }

    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val localPath = saveProductImageToInternalStorage(context, uri)
            EquipmentCatalogData.updateProduct(context, product.copy(imageUrl = localPath))
            Toast.makeText(context, "تم حفظ صورة المنتج الجديدة 🖼️", Toast.LENGTH_SHORT).show()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(product.emoji, fontSize = 28.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "تفاصيل المعدة",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (product.imageUrl.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        AsyncImage(
                            model = product.imageUrl,
                            contentDescription = name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.65f),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "تغيير الصورة",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تغيير الصورة 🖼️", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                } else {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إضافة صورة لهذا المنتج 🖼️",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Text(
                    text = name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "المواصفات الفنية المعتمدة:",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                specs.forEach { spec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = spec,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${product.priceDzd} ${Strings.get("currency_dzd")}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = Strings.get("in_stock"),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF4CAF50),
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Button(
                        onClick = onAddToCart,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3D00)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = Strings.get("add_to_cart"),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OrderCartSheet(
    cartItemsMap: Map<String, Int>,
    allProducts: List<EquipmentProduct>,
    currentLang: AppLanguage,
    onDismiss: () -> Unit,
    onUpdateQuantity: (String, Int) -> Unit,
    onClearCart: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current

    var technicianName by remember { mutableStateOf("") }
    var technicianPhone by remember { mutableStateOf("") }
    var technicianWilaya by remember { mutableStateOf("") }

    val totalPrice = cartItemsMap.entries.sumOf { (id, qty) ->
        val prod = allProducts.find { it.id == id }
        (prod?.priceDzd ?: 0) * qty
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShoppingBag,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Strings.get("cart_title"),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                IconButton(onClick = onClearCart) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear",
                        tint = Color.Red
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Cart Items List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItemsMap.entries.toList()) { (id, qty) ->
                    val prod = allProducts.find { it.id == id } ?: return@items
                    val prodName = when (currentLang) {
                        AppLanguage.ARABIC -> prod.nameAr
                        AppLanguage.ENGLISH -> prod.nameEn
                        AppLanguage.FRENCH -> prod.nameFr
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (prod.imageUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = prod.imageUrl,
                                        contentDescription = prodName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                } else {
                                    Text(prod.emoji, fontSize = 20.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = prodName,
                                        style = MaterialTheme.typography.labelLarge.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${prod.priceDzd} ${Strings.get("currency_dzd")} × $qty",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { onUpdateQuantity(id, qty - 1) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.outlineVariant),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(28.dp),
                                    shape = CircleShape
                                ) {
                                    Text("-", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                Text(
                                    text = qty.toString(),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = { onUpdateQuantity(id, qty + 1) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.size(28.dp),
                                    shape = CircleShape
                                ) {
                                    Text("+", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimary)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Technician Details Inputs
            Text(
                text = "معلومات التوصيل (الاسم، الهاتف):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = technicianName,
                    onValueChange = { technicianName = it },
                    placeholder = { Text("الاسم الكامل", fontSize = 12.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tech_name_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = technicianPhone,
                    onValueChange = { technicianPhone = it },
                    placeholder = { Text("رقم الهاتف", fontSize = 12.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tech_phone_input"),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Payment Method Selector for Cart Order
            var selectedPayMethod by remember { mutableStateOf("baridimob") }
            val clipboardManager = LocalClipboardManager.current
            val settings = AppSettingsManager.currentSettings.value

            Text(
                text = "اختر طريقة الدفع للطلب:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "baridimob" to "📮 بريدي موب",
                    "visa" to "💳 فيزا",
                    "usdt" to "🪙 USDT",
                    "cod" to "💵 عند الاستلام"
                ).forEach { (key, label) ->
                    val isSelected = selectedPayMethod == key
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPayMethod = key }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Show selected payment detail with copy button
            val activeDetailText = when (selectedPayMethod) {
                "baridimob" -> settings.baridiMobRip
                "visa" -> settings.visaCardDetails
                "usdt" -> settings.usdtWalletAddress
                else -> "الدفع عند استلام الطرد مع موزع التوصيل"
            }

            if (selectedPayMethod != "cod" && activeDetailText.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeDetailText,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(activeDetailText))
                                Toast.makeText(context, Strings.get("copy_copied"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Total & Dispatch WhatsApp Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الإجمالي: $totalPrice ${Strings.get("currency_dzd")}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                Button(
                    onClick = {
                        val itemsText = cartItemsMap.entries.joinToString("\n") { (id, qty) ->
                            val p = allProducts.find { it.id == id }
                            "• ${p?.nameAr} - العدد: $qty"
                        }

                        val payLabel = when (selectedPayMethod) {
                            "baridimob" -> "بريدي موب (BaridiMob)"
                            "visa" -> "فيزا كارت (Visa Card)"
                            "usdt" -> "USDT TRC20"
                            else -> "الدفع عند الاستلام"
                        }

                        val message = """
                            طلب جديد لعتاد تغيير الزجاج 🛠️
                            
                            الاسم: ${technicianName.ifBlank { "فني صيانة" }}
                            الهاتف: ${technicianPhone.ifBlank { "غير مدخل" }}
                            طريقة الدفع المحددة: $payLabel
                            
                            المنتجات المطلوبة:
                            $itemsText
                            
                            المبلغ الإجمالي: $totalPrice د.ج
                        """.trimIndent()

                        val contactPhone = AppSettingsManager.currentSettings.value.phoneNumber.replace(" ", "").replace("+", "")
                        val formattedPhone = if (contactPhone.startsWith("0")) "+213${contactPhone.substring(1)}" else "+213$contactPhone"

                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}")
                        }

                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "جاري إرسال الطلب...", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("submit_whatsapp_order")
                ) {
                    Text(
                        text = "📱 " + Strings.get("order_via_whatsapp"),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun SubscriptionPaymentModal(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val settings = AppSettingsManager.currentSettings.value

    var selectedPlan by remember { mutableStateOf("yearly") } // "monthly" or "yearly"
    var selectedPayMethod by remember { mutableStateOf("baridimob") } // "baridimob", "visa", "usdt"
    var userName by remember { mutableStateOf("") }
    var userPhone by remember { mutableStateOf("") }
    var showEditAppSettings by remember { mutableStateOf(false) }

    val planPrice = if (selectedPlan == "yearly") settings.yearlySubPriceDzd else settings.monthlySubPriceDzd
    val planTitle = if (selectedPlan == "yearly") "الاشتراك السنوي (Yearly VIP)" else "الاشتراك الشهري (Monthly VIP)"

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CardMembership,
                            contentDescription = null,
                            tint = Color(0xFFFF3D00),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Strings.get("subscription_hub_title"),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    Row {
                        IconButton(onClick = { showEditAppSettings = true }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Settings",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Plan Selection Cards
                Text(
                    text = "1️⃣ اختر باقة الاشتراك المناسبة لك:",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Monthly Plan Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPlan = "monthly" },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPlan == "monthly") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.5.dp, if (selectedPlan == "monthly") MaterialTheme.colorScheme.primary else Color.Transparent),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("⚡ شهري", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${settings.monthlySubPriceDzd} د.ج",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }

                    // Yearly Plan Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPlan = "yearly" },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPlan == "yearly") Color(0xFFFF3D00).copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.5.dp, if (selectedPlan == "yearly") Color(0xFFFF3D00) else Color.Transparent),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("👑 سنوي", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFFFF3D00)) {
                                    Text("توفير 🔥", color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${settings.yearlySubPriceDzd} د.ج",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFF3D00)
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Method Selector
                Text(
                    text = "2️⃣ اختر طريقة الدفع:",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // BaridiMob
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedPayMethod == "baridimob") Color(0xFF00C853) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (selectedPayMethod == "baridimob") Color(0xFF00C853) else MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPayMethod = "baridimob" }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = if (selectedPayMethod == "baridimob") Color.White else MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("بريدي موب", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedPayMethod == "baridimob") Color.White else MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    // Visa Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedPayMethod == "visa") Color(0xFF2979FF) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (selectedPayMethod == "visa") Color(0xFF2979FF) else MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPayMethod = "visa" }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = if (selectedPayMethod == "visa") Color.White else MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("فيزا كارت", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedPayMethod == "visa") Color.White else MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    // USDT
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selectedPayMethod == "usdt") Color(0xFFFFD600) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (selectedPayMethod == "usdt") Color(0xFFFFD600) else MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedPayMethod = "usdt" }
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.CurrencyBitcoin, contentDescription = null, tint = if (selectedPayMethod == "usdt") Color.Black else MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("USDT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedPayMethod == "usdt") Color.Black else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Account / Wallet Box with One-Click Copy
                val payDetails = when (selectedPayMethod) {
                    "baridimob" -> settings.baridiMobRip
                    "visa" -> settings.visaCardDetails
                    else -> settings.usdtWalletAddress
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = when (selectedPayMethod) {
                                "baridimob" -> "📮 رقم الحساب البريدي RIP / BaridiMob:"
                                "visa" -> "💳 تفاصيل بطاقة فيزا / ماستركارد:"
                                else -> "🪙 عنوان محفظة USDT (TRC20):"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = payDetails,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(payDetails))
                                    Toast.makeText(context, Strings.get("copy_copied"), Toast.LENGTH_SHORT).show()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("نسخ", fontSize = 11.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // User details
                Text(
                    text = "3️⃣ أدخل بياناتك لتأكيد التفعيل:",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = userName,
                    onValueChange = { userName = it },
                    placeholder = { Text("الاسم واللقب / اسم المحل") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = userPhone,
                    onValueChange = { userPhone = it },
                    placeholder = { Text("رقم الهاتف لتفعيل الحساب") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Confirm via WhatsApp Button
                Button(
                    onClick = {
                        val payLabel = when (selectedPayMethod) {
                            "baridimob" -> "بريدي موب (BaridiMob RIP)"
                            "visa" -> "فيزا كارت (Visa Card)"
                            else -> "USDT TRC20 Crypto"
                        }

                        val message = """
                            طلب تفعيل اشتراك جديد 👑
                            
                            الباقة المطلوبة: $planTitle
                            المبلغ: $planPrice د.ج
                            طريقة الدفع المعتمدة: $payLabel
                            
                            الاسم / المحل: ${userName.ifBlank { "فني صيانة" }}
                            الهاتف: ${userPhone.ifBlank { "غير مدخل" }}
                            
                            ملاحظة: مرفق وصل التحويل/الدفع بالتكبير.
                        """.trimIndent()

                        val contactPhone = settings.phoneNumber.replace(" ", "").replace("+", "")
                        val formattedPhone = if (contactPhone.startsWith("0")) "+213${contactPhone.substring(1)}" else "+213$contactPhone"

                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=${Uri.encode(message)}")
                        }

                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "جاري الإرسال عبر واتساب...", Toast.LENGTH_SHORT).show()
                        }
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = "📱 " + Strings.get("confirm_send_receipt"),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Direct Edit Subscription, Prices & Payment Methods Button
                OutlinedButton(
                    onClick = { showEditAppSettings = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_edit_subscription_settings"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "⚙️ تعديل أسعار الاشتراك وطرق الدفع",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }

    if (showEditAppSettings) {
        EditAppSettingsDialog(
            onDismiss = { showEditAppSettings = false }
        )
    }
}

